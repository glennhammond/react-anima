import React from "react";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import { Accordion } from "./screens/Accordion";
import { AssetInventory } from "./screens/AssetInventory";
import { AtomicDesign } from "./screens/AtomicDesign";
import { Atoms } from "./screens/Atoms";
import { Buttons } from "./screens/Buttons";
import { Colors } from "./screens/Colors";
import { Contents } from "./screens/Contents";
import { CoreMoreBore } from "./screens/CoreMoreBore";
import { CourseStructure } from "./screens/CourseStructure";
import { Design } from "./screens/Design";
import { Development } from "./screens/Development";
import { Documentation } from "./screens/Documentation";
import { ElearningDesign } from "./screens/ElearningDesign";
import { Hp } from "./screens/Hp";
import { Icons } from "./screens/Icons";
import { Info } from "./screens/Info";
import { InfoRoleA } from "./screens/InfoRoleA";
import { Molecules } from "./screens/Molecules";
import { Organisms } from "./screens/Organisms";
import { Pages } from "./screens/Pages";
import { Rise } from "./screens/Rise";
import { Storyline } from "./screens/Storyline";
import { Tabs } from "./screens/Tabs";
import { Templates } from "./screens/Templates";
import { Typo } from "./screens/Typo";
import { Typography } from "./screens/Typography";

const router = createBrowserRouter([
  {
    path: "/*",
    element: <Development />,
  },
  {
    path: "/development",
    element: <Development />,
  },
  {
    path: "/organisms",
    element: <Organisms />,
  },
  {
    path: "/contents",
    element: <Contents />,
  },
  {
    path: "/molecules",
    element: <Molecules />,
  },
  {
    path: "/design",
    element: <Design />,
  },
  {
    path: "/documentation",
    element: <Documentation />,
  },
  {
    path: "/rise",
    element: <Rise />,
  },
  {
    path: "/h5p",
    element: <Hp />,
  },
  {
    path: "/storyline",
    element: <Storyline />,
  },
  {
    path: "/atoms",
    element: <Atoms />,
  },
  {
    path: "/atomic-design",
    element: <AtomicDesign />,
  },
  {
    path: "/elearning-design-system-overview",
    element: <ElearningDesign />,
  },
  {
    path: "/core-more-u38-bore",
    element: <CoreMoreBore />,
  },
  {
    path: "/course-structure",
    element: <CourseStructure />,
  },
  {
    path: "/asset-inventory",
    element: <AssetInventory />,
  },
  {
    path: "/info-1",
    element: <Info />,
  },
  {
    path: "/info-role-a",
    element: <InfoRoleA />,
  },
  {
    path: "/accordion",
    element: <Accordion />,
  },
  {
    path: "/tabs",
    element: <Tabs />,
  },
  {
    path: "/colors",
    element: <Colors />,
  },
  {
    path: "/icons",
    element: <Icons />,
  },
  {
    path: "/pages",
    element: <Pages />,
  },
  {
    path: "/typo",
    element: <Typo />,
  },
  {
    path: "/buttons",
    element: <Buttons />,
  },
  {
    path: "/templates",
    element: <Templates />,
  },
  {
    path: "/typography-2",
    element: <Typography />,
  },
]);

export const App = () => {
  return <RouterProvider router={router} />;
};
