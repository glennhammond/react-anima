/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const BgIcon = ({ className }) => {
  return (
    <svg
      className={`bg-icon ${className}`}
      fill="none"
      height="100"
      viewBox="0 0 800 100"
      width="800"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M0 50C0 22.3858 22.3858 0 50 0H750C777.614 0 800 22.3858 800 50C800 77.6142 777.614 100 750 100H50C22.3858 100 0 77.6142 0 50Z"
        fill="white"
      />
    </svg>
  );
};
