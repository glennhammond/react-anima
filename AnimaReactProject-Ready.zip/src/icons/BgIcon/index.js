export { BgIcon } from "./BgIcon";
