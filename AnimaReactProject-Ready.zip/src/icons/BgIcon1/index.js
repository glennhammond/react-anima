export { BgIcon1 } from "./BgIcon1";
