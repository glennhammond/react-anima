export { BgIcon2 } from "./BgIcon2";
