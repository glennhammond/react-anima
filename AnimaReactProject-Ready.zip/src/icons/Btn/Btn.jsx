/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Btn = ({ className }) => {
  return (
    <svg
      className={`btn ${className}`}
      fill="none"
      height="51"
      viewBox="0 0 144 51"
      width="144"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M118.5 1C132.031 1 143 11.969 143 25.5C143 39.031 132.031 50 118.5 50H25.5C11.969 50 1 39.031 1 25.5C1 11.969 11.969 1 25.5 1H118.5Z"
        stroke="white"
        strokeWidth="2"
      />
    </svg>
  );
};
