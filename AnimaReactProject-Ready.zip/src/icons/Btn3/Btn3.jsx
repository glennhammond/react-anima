/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Btn3 = ({ className }) => {
  return (
    <svg
      className={`btn-3 ${className}`}
      fill="none"
      height="45"
      viewBox="0 0 104 45"
      width="104"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M81.5918 1C93.4152 1 103 10.5848 103 22.4082C103 34.2316 93.4152 43.8164 81.5918 43.8164H22.4082C10.5848 43.8164 1.00002 34.2316 1 22.4082C1 10.5848 10.5848 1 22.4082 1H81.5918Z"
        stroke="#005680"
        strokeWidth="2"
      />
    </svg>
  );
};
