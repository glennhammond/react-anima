/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Btn4 = ({ className }) => {
  return (
    <svg
      className={`btn-4 ${className}`}
      fill="none"
      height="45"
      viewBox="0 0 104 45"
      width="104"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect
        className="rect"
        fill="white"
        height="41"
        transform="translate(2 2)"
        width="100"
      />

      <path
        className="path"
        d="M81.5 1C93.3741 1 103 10.6259 103 22.5C103 34.3741 93.3741 44 81.5 44H22.5C10.6259 44 1 34.3741 1 22.5C1 10.6259 10.6259 1 22.5 1H81.5Z"
        fill="#005680"
        stroke="#005680"
        strokeWidth="2"
      />
    </svg>
  );
};
