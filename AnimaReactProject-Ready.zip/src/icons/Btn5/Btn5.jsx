/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Btn5 = ({ className }) => {
  return (
    <svg
      className={`btn-5 ${className}`}
      fill="none"
      height="62"
      viewBox="0 0 144 62"
      width="144"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M113.059 1.79077L113.819 1.80054C129.747 2.20416 142.535 15.2423 142.535 31.2673C142.535 47.5467 129.338 60.7438 113.059 60.7439H30.4766C14.1972 60.7439 1.00003 47.5467 1 31.2673C1 14.9879 14.1971 1.79077 30.4766 1.79077H113.059Z"
        stroke="#005680"
        strokeWidth="2"
      />
    </svg>
  );
};
