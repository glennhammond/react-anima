/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Check = ({ className }) => {
  return (
    <svg
      className={`check ${className}`}
      fill="none"
      height="16"
      viewBox="0 0 16 16"
      width="16"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M15.1789 2.42682L5.81605 13.6623L0.855469 8.55999L1.81146 7.63055L5.73977 11.6711L14.1547 1.57324L15.1789 2.42682Z"
        fill="#005680"
      />
    </svg>
  );
};
