export { CloseSmall1 } from "./CloseSmall1";
