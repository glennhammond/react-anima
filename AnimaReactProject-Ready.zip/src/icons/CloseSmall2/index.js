export { CloseSmall2 } from "./CloseSmall2";
