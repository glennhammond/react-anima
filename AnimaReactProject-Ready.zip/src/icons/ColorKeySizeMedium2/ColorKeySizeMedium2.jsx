/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";

export const ColorKeySizeMedium2 = ({ color = "black", className }) => {
  return (
    <svg
      className={`color-key-size-medium-2 ${className}`}
      fill="none"
      height="80"
      viewBox="0 0 80 80"
      width="80"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M28.6328 55.3L43.8995 40L28.6328 24.7L33.3328 20L53.3328 40L33.3328 60L28.6328 55.3Z"
        fill={color}
      />
    </svg>
  );
};

ColorKeySizeMedium2.propTypes = {
  color: PropTypes.string,
};
