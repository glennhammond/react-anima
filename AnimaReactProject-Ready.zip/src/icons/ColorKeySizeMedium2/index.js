export { ColorKeySizeMedium2 } from "./ColorKeySizeMedium2";
