/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";

export const IconArrowLeft1 = ({ color = "black", className }) => {
  return (
    <svg
      className={`icon-arrow-left-1 ${className}`}
      fill="none"
      height="80"
      viewBox="0 0 80 80"
      width="80"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M51.3672 24.7L36.1005 40L51.3672 55.3L46.6672 60L26.6672 40L46.6672 20L51.3672 24.7Z"
        fill={color}
      />
    </svg>
  );
};

IconArrowLeft1.propTypes = {
  color: PropTypes.string,
};
