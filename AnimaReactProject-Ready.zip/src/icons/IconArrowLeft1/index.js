export { IconArrowLeft1 } from "./IconArrowLeft1";
