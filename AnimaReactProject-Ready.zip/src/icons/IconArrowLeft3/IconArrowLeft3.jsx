/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const IconArrowLeft3 = ({ className }) => {
  return (
    <svg
      className={`icon-arrow-left-3 ${className}`}
      fill="none"
      height="40"
      viewBox="0 0 40 40"
      width="40"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g className="g" clipPath="url(#clip0_5_7117)">
        <path
          className="path"
          d="M14.3164 27.65L21.9497 20L14.3164 12.35L16.6664 10L26.6664 20L16.6664 30L14.3164 27.65Z"
          fill="white"
        />
      </g>

      <defs className="defs">
        <clipPath className="clip-path" id="clip0_5_7117">
          <rect
            className="rect"
            fill="white"
            height="40"
            transform="translate(0 40) rotate(-90)"
            width="40"
          />
        </clipPath>
      </defs>
    </svg>
  );
};
