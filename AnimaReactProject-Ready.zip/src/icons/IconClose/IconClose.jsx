/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";

export const IconClose = ({ color = "white", className }) => {
  return (
    <svg
      className={`icon-close ${className}`}
      fill="none"
      height="50"
      viewBox="0 0 50 50"
      width="50"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g className="g" clipPath="url(#clip0_5_6008)">
        <path
          className="path"
          d="M39.5827 13.3541L36.6452 10.4166L24.9993 22.0625L13.3535 10.4166L10.416 13.3541L22.0619 25L10.416 36.6458L13.3535 39.5833L24.9993 27.9375L36.6452 39.5833L39.5827 36.6458L27.9368 25L39.5827 13.3541Z"
          fill={color}
        />
      </g>

      <defs className="defs">
        <clipPath className="clip-path" id="clip0_5_6008">
          <rect className="rect" fill="white" height="50" width="50" />
        </clipPath>
      </defs>
    </svg>
  );
};

IconClose.propTypes = {
  color: PropTypes.string,
};
