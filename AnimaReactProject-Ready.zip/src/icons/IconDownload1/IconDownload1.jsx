/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const IconDownload1 = ({ className }) => {
  return (
    <svg
      className={`icon-download-1 ${className}`}
      fill="none"
      height="76"
      viewBox="0 0 63 76"
      width="63"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M62.2094 26.6612H44.4353V0H17.7741V26.6612H0L31.1047 57.7659L62.2094 26.6612ZM0 66.6529V75.54H62.2094V66.6529H0Z"
        fill="#005680"
      />
    </svg>
  );
};
