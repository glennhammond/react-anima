/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const IconMore = ({ className }) => {
  return (
    <svg
      className={`icon-more ${className}`}
      fill="none"
      height="18"
      viewBox="0 0 72 18"
      width="72"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M9 0C4.05 0 0 4.05 0 9C0 13.95 4.05 18 9 18C13.95 18 18 13.95 18 9C18 4.05 13.95 0 9 0ZM63 0C58.05 0 54 4.05 54 9C54 13.95 58.05 18 63 18C67.95 18 72 13.95 72 9C72 4.05 67.95 0 63 0ZM36 0C31.05 0 27 4.05 27 9C27 13.95 31.05 18 36 18C40.95 18 45 13.95 45 9C45 4.05 40.95 0 36 0Z"
        fill="black"
      />
    </svg>
  );
};
