/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const LineLdown3 = ({ className }) => {
  return (
    <svg
      className={`line-ldown-3 ${className}`}
      fill="none"
      height="8"
      viewBox="0 0 8 8"
      width="8"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        clipRule="evenodd"
        d="M4.00014 5.19521L6.76444 2.43091L7.23584 2.90231L4.00014 6.13801L0.764435 2.90231L1.23584 2.43091L4.00014 5.19521Z"
        fill="#94A3B8"
        fillRule="evenodd"
      />
    </svg>
  );
};
