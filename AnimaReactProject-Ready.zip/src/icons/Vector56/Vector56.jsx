/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Vector56 = ({ className }) => {
  return (
    <svg
      className={`vector-56 ${className}`}
      fill="none"
      height="77"
      viewBox="0 0 81 77"
      width="81"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        clipRule="evenodd"
        d="M40.4766 0L30.9669 29.4735L0 29.4142L25.0876 47.5639L15.4615 77L40.4788 58.7427L65.4983 76.9934L55.87 47.5639L80.962 29.4076L49.9907 29.4735L40.4766 0Z"
        fill="#FFC72A"
        fillRule="evenodd"
      />
    </svg>
  );
};
