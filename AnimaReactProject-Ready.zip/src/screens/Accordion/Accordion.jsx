import React from "react";
import "./style.css";

export const Accordion = () => {
  return (
    <div className="accordion">
      <div className="div-27">
        <div className="divider-36">
          <img
            className="devider-horizon-36"
            alt="Devider horizon"
            src="/img/devider-horizon-9.png"
          />
        </div>

        <div className="frame-52">
          <div className="header-52">Licence</div>

          <p className="header-53">License information is on the last page.</p>
        </div>

        <div className="page-footer-16">
          <div className="credit-16">
            <div className="text-wrapper-81">© Glenn Hammond</div>
          </div>
        </div>

        <div className="page-title-16">
          <div className="title-32">
            <div className="title-33">Accordion</div>
          </div>
        </div>

        <div className="rectangle-69" />

        <div className="section-meta-16">
          <div className="text-wrapper-82">Contents</div>
        </div>
      </div>
    </div>
  );
};
