import React from "react";
import { Link } from "react-router-dom";
import "./style.css";

export const AssetInventory = () => {
  return (
    <div className="asset-inventory">
      <div className="div-24">
        <div className="overlap-56">
          <div className="page-title-15">
            <div className="title-30">
              <div className="title-31">Asset Inventory</div>
            </div>
          </div>

          <img
            className="devider-horizon-34"
            alt="Devider horizon"
            src="/img/devider-horizon-18.svg"
          />
        </div>

        <div className="page-header-15">
          <Link className="section-meta-15" to="/contents">
            <div className="text-wrapper-68">Contents</div>
          </Link>

          <Link className="section-meta-15" to="/documentation">
            <div className="text-wrapper-68">Documentation</div>
          </Link>

          <Link className="section-meta-15" to="/design">
            <div className="text-wrapper-68">Design</div>
          </Link>

          <Link className="section-meta-15" to="/development">
            <div className="text-wrapper-68">Development</div>
          </Link>

          <div className="logo-15" />
        </div>

        <div className="overlap-57">
          <div className="page-footer-15">
            <div className="credit-15">
              <div className="text-wrapper-69">© Glenn Hammond</div>
            </div>
          </div>

          <div className="group-51">
            <div className="typography-29">
              <div className="heading-13">Tab 1</div>
            </div>

            <div className="typography-30">
              <div className="heading-13">Tab 2</div>
            </div>

            <div className="overlap-58">
              <div className="typography-31">
                <div className="heading-13">Tab 3</div>
              </div>
            </div>

            <div className="typography-32">
              <div className="heading-13">Tab 4</div>
            </div>

            <div className="overlap-59">
              <div className="typography-33">
                <div className="heading-14">Tab Three</div>
              </div>
            </div>
          </div>
        </div>

        <div className="rectangle-67" />

        <div className="overlap-60">
          <div className="divider-33">
            <img
              className="devider-horizon-35"
              alt="Devider horizon"
              src="/img/devider-horizon.svg"
            />
          </div>

          <div className="row-assets-12">
            <div className="row-assets-13">
              <div className="title-doc-18">
                <div className="header-50">Assets</div>

                <p className="header-51">
                  Images, media, and content files prepared for use.
                </p>
              </div>

              <p className="text-wrapper-70">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris
                nisi ut aliquip ex ea commodo consequat.
              </p>

              <div className="divider-34">
                <div className="overlap-group-27">
                  <img
                    className="devider-horizon-35"
                    alt="Devider horizon"
                    src="/img/devider-horizon.svg"
                  />

                  <div className="divider-35">
                    <img
                      className="devider-horizon-35"
                      alt="Devider horizon"
                      src="/img/devider-horizon.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="rectangle-68" />

        <img
          className="group-52"
          alt="Group"
          src="/img/devider-horizon-9.png"
        />

        <div className="table-wrapper">
          <div className="table">
            <div className="row">
              <div className="cell">
                <div className="content">
                  <div className="text-2">Component</div>
                </div>
              </div>

              <div className="cell">
                <div className="content">
                  <div className="text-2">variants</div>
                </div>
              </div>

              <div className="cell">
                <div className="content">
                  <div className="text-2">Type</div>
                </div>
              </div>

              <div className="cell">
                <div className="content">
                  <div className="text-2">Dimensions</div>
                </div>
              </div>

              <div className="cell">
                <div className="content">
                  <div className="text-2">Filename</div>
                </div>
              </div>

              <div className="cell">
                <div className="content">
                  <div className="text-2">Platform</div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Icon bg</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Stroke, Filled</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Atom</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">24x24</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">icon/small/action/save</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Storyline/ Rise</div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Icon bg</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Stroke, Filled</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Atom</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">24x24</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">icon/small/action/save</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Storyline/ Rise</div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Icon (Small)</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Stroke, Filled</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Atom</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">24x24</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">icon/small/action/save</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Storyline/ Rise</div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Icon (Medium)</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Stroke, Filled</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Atom</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">32x32</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">icon/medium/action/info</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Storyline/ Rise</div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Icon (Large)</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Stroke, Filled</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Atom</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <p className="text-4">
                    <span className="text-wrapper-71">32x32 </span>

                    <span className="text-wrapper-72">&nbsp;</span>
                  </p>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">icon/medium/action/info</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Storyline/ Rise</div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Image Placeholder</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">1:1, 4:3, 16:9</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Atom</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <p className="text-3">400x400 / 640x480 / 960x540</p>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">img/placeholder/16x9</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Storyline/ Rise</div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Primary Button</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Default, Hover, Disabled</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Atom</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">160x48</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">btn/primary/default</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Storyline/ Rise</div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Button Group</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Horizontal, Vertical</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Molecule</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Depends on button count</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">btn/group/horizontal</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Storyline/ Rise</div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Progress Indicator</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Horizontal, Stepper</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Molecule</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">960x60</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">progress/horizontal/stepper</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Storyline</div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Text Input Field</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Focused, Error, Success</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Molecule</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-5">280x48</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">form/input/text/default</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Storyline/ Rise</div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">CTA Section</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">One-line, Two-line</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Organism</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Full width, height auto</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">section/cta/two-line</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Rise</div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Quiz Card</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">With/without image</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Organism</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">640x360</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">card/quiz/image-text</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Storyline</div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Top Navigation</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Sticky, Mobile</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Organism</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">1920x80</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">nav/top/default</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Storyline/ Rise</div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Typography Set</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">H1�H6, Body, Caption</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">System</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Responsive</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">text/styles/body/default</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Storyline/ Rise</div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Content Layout Grid</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">1-col, 2-col, 3-col</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Template</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">19200 max width</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">layout/grid/2-col</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Storyline/ Rise</div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Modal (Large)</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Info, Confirm, Warning</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Template</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">800x600</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">modal/large/info</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Storyline</div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Modal (Small)</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">Info, Confirm</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Template</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">480x320</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-3">modal/small/info</div>
                </div>
              </div>

              <div className="content-wrapper">
                <div className="content">
                  <div className="text-4">Storyline</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
