import React from "react";
import { Link } from "react-router-dom";
import { IconDownload1 } from "../../icons/IconDownload1";
import { IconMore } from "../../icons/IconMore";
import { Vector56 } from "../../icons/Vector56";
import "./style.css";

export const AtomicDesign = () => {
  return (
    <div className="atomic-design">
      <div className="div-17">
        <div className="overlap-45">
          <div className="page-title-11">
            <div className="title-22">
              <div className="title-23">Atomic Design</div>
            </div>
          </div>

          <img
            className="devider-horizon-23"
            alt="Devider horizon"
            src="/img/devider-horizon-18.svg"
          />
        </div>

        <div className="page-header-11">
          <Link className="section-meta-11" to="/contents">
            <div className="text-wrapper-48">Contents</div>
          </Link>

          <Link className="section-meta-11" to="/documentation">
            <div className="text-wrapper-48">Documentation</div>
          </Link>

          <Link className="section-meta-11" to="/design">
            <div className="text-wrapper-48">Design</div>
          </Link>

          <Link className="section-meta-11" to="/development">
            <div className="text-wrapper-48">Development</div>
          </Link>

          <div className="logo-11" />
        </div>

        <div className="page-footer-11">
          <div className="credit-11">
            <div className="text-wrapper-49">© Glenn Hammond</div>
          </div>
        </div>

        <div className="rectangle-57" />

        <div className="overlap-46">
          <div className="divider-23">
            <img
              className="devider-horizon-24"
              alt="Devider horizon"
              src="/img/devider-horizon.svg"
            />
          </div>

          <div className="row-assets-8">
            <div className="overlap-47">
              <div className="row-assets-9">
                <div className="divider-24">
                  <img
                    className="devider-horizon-24"
                    alt="Devider horizon"
                    src="/img/devider-horizon.svg"
                  />
                </div>

                <div className="title-doc-14">
                  <div className="header-37">Assets</div>

                  <p className="header-38">
                    Images, media, and content files prepared for use.
                  </p>
                </div>

                <div className="overlap-48">
                  <div className="card-typography-2">
                    <div className="div-18">
                      <div className="typography-22">
                        <div className="overlap-group-22">
                          <img
                            className="line-19"
                            alt="Line"
                            src="/img/line-1-1.svg"
                          />

                          <img
                            className="line-20"
                            alt="Line"
                            src="/img/line-4-1.svg"
                          />

                          <img
                            className="line-21"
                            alt="Line"
                            src="/img/line-1-1.svg"
                          />

                          <img
                            className="line-22"
                            alt="Line"
                            src="/img/line-1-1.svg"
                          />

                          <div className="text-wrapper-50">Aa</div>
                        </div>
                      </div>
                    </div>

                    <div className="frame-49">
                      <a
                        className="header-39"
                        href="https://www.figma.com/design/1dRIYueVCwnBJZ3ciZyueJ?node-id=2100-12473"
                        rel="noopener noreferrer"
                        target="_blank"
                      >
                        Typography
                      </a>

                      <div className="header-40">14 styles</div>
                    </div>
                  </div>

                  <div className="div-19">
                    <div className="div-18">
                      <div className="icons-5">
                        <Vector56 className="vector-37" />
                        <IconDownload1 className="icon-download-2" />
                        <IconMore className="icon-more-3" />
                      </div>
                    </div>

                    <div className="frame-49">
                      <p className="header-41">
                        <a
                          href="https://www.figma.com/design/1dRIYueVCwnBJZ3ciZyueJ?node-id=2105-13582"
                          rel="noopener noreferrer"
                          target="_blank"
                        >
                          <span className="text-wrapper-51">Icon</span>
                        </a>

                        <span className="text-wrapper-52">s</span>
                      </p>

                      <div className="header-40">121 icons</div>
                    </div>
                  </div>

                  <div className="div-20">
                    <div className="div-18">
                      <div className="group-43">
                        <div className="overlap-group-23">
                          <img
                            className="rectangle-58"
                            alt="Rectangle"
                            src="/img/rectangle-3467559-3.svg"
                          />

                          <img
                            className="rectangle-59"
                            alt="Rectangle"
                            src="/img/rectangle-3467558-3.svg"
                          />

                          <img
                            className="rectangle-60"
                            alt="Rectangle"
                            src="/img/rectangle-3467557-3.svg"
                          />

                          <div className="ellipse-15" />
                        </div>
                      </div>
                    </div>

                    <div className="frame-49">
                      <p className="header-41">
                        <a
                          href="https://www.figma.com/design/1dRIYueVCwnBJZ3ciZyueJ?node-id=2100-12472"
                          rel="noopener noreferrer"
                          target="_blank"
                        >
                          <span className="text-wrapper-51">Colour</span>
                        </a>

                        <span className="text-wrapper-52">s</span>
                      </p>

                      <div className="header-40">78 styles</div>
                    </div>
                  </div>

                  <div className="group-44">
                    <Link className="card-atoms-3" to="/atoms">
                      <div className="div-18">
                        <img
                          className="vector-38"
                          alt="Vector"
                          src="/img/vector-80.svg"
                        />
                      </div>

                      <div className="frame-49">
                        <div className="header-42">Atoms</div>

                        <p className="header-43">
                          Fundamental UI elements that can’t be broken down
                          further.
                        </p>
                      </div>
                    </Link>

                    <Link className="card-atoms-4" to="/molecules">
                      <div className="div-18">
                        <img
                          className="vector-39"
                          alt="Vector"
                          src="/img/vector-81.svg"
                        />
                      </div>

                      <div className="frame-49">
                        <div className="header-42">Molecules</div>

                        <p className="header-40">
                          Groups of atoms working together as a unit.
                        </p>
                      </div>
                    </Link>

                    <Link className="card-atoms-5" to="/organisms">
                      <div className="div-18">
                        <img
                          className="vector-40"
                          alt="Vector"
                          src="/img/vector-82.svg"
                        />
                      </div>

                      <div className="frame-49">
                        <div className="header-42">Organisms</div>

                        <p className="header-40">
                          Groups of molecules forming a distinct section of the
                          interface.
                        </p>
                      </div>
                    </Link>
                  </div>
                </div>
              </div>

              <div className="group-45">
                <div className="div-20">
                  <div className="div-18" />

                  <div className="frame-49">
                    <div className="header-42">Templates</div>

                    <p className="header-43">
                      Fundamental UI elements that can’t be broken down further.
                    </p>
                  </div>
                </div>

                <div className="card-atoms-6">
                  <div className="div-18" />

                  <div className="frame-49">
                    <div className="header-42">Pages</div>

                    <p className="header-40">
                      Groups of atoms working together as a unit.
                    </p>
                  </div>
                </div>

                <div className="div-19">
                  <div className="div-18">
                    <img
                      className="vector-40"
                      alt="Vector"
                      src="/img/vector-82.svg"
                    />
                  </div>

                  <div className="frame-49">
                    <div className="header-42">Organisms</div>

                    <p className="header-40">
                      Groups of molecules forming a distinct section of the
                      interface.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="divider-25">
          <img
            className="devider-horizon-25"
            alt="Devider horizon"
            src="/img/devider-horizon-62.svg"
          />
        </div>

        <p className="text-wrapper-53">
          Finalised, content-rich screens built from templates. These are what
          the learner experiences—like intros, scenarios, quizzes, and result
          screens.
        </p>

        <div className="card-atoms-7">
          <div className="div-18" />

          <div className="frame-49">
            <div className="header-42">Pages</div>

            <p className="header-40">
              Finalised screens using real content, derived from templates.
            </p>
          </div>
        </div>

        <div className="rectangle-61" />
      </div>
    </div>
  );
};
