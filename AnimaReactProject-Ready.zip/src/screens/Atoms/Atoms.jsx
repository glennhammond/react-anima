import React from "react";
import { Link } from "react-router-dom";
import { IconDownload1 } from "../../icons/IconDownload1";
import { IconMore } from "../../icons/IconMore";
import { Vector56 } from "../../icons/Vector56";
import "./style.css";

export const Atoms = () => {
  return (
    <div className="atoms">
      <div className="div-16">
        <div className="overlap-42">
          <div className="page-title-10">
            <div className="title-20">
              <div className="title-21">Atoms</div>
            </div>
          </div>

          <img
            className="devider-horizon-21"
            alt="Devider horizon"
            src="/img/devider-horizon-18.svg"
          />
        </div>

        <div className="page-header-10">
          <Link className="section-meta-10" to="/contents">
            <div className="text-wrapper-42">Contents</div>
          </Link>

          <Link className="section-meta-10" to="/documentation">
            <div className="text-wrapper-42">Documentation</div>
          </Link>

          <Link className="section-meta-10" to="/design">
            <div className="text-wrapper-42">Design</div>
          </Link>

          <Link className="section-meta-10" to="/development">
            <div className="text-wrapper-42">Development</div>
          </Link>

          <div className="logo-10" />
        </div>

        <div className="page-footer-10">
          <div className="credit-10">
            <div className="text-wrapper-43">© Glenn Hammond</div>
          </div>
        </div>

        <div className="rectangle-51" />

        <div className="overlap-43">
          <div className="divider-21">
            <img
              className="devider-horizon-22"
              alt="Devider horizon"
              src="/img/devider-horizon.svg"
            />
          </div>

          <div className="row-assets-6">
            <div className="row-assets-7">
              <div className="title-doc-13">
                <div className="header-33">Building Blocks</div>

                <p className="header-34">
                  Images, media, and content files prepared for use.
                </p>
              </div>

              <p className="text-wrapper-44">
                Atoms are the fundamental building blocks of a design system.
                They include the most basic UI elements such as buttons, input
                fields, labels, colours, and icons. While they don’t carry much
                functionality on their own, atoms serve as the essential
                foundation for all higher-level components, ensuring consistency
                in style and behaviour across the interface.
              </p>

              <div className="divider-22">
                <img
                  className="devider-horizon-22"
                  alt="Devider horizon"
                  src="/img/devider-horizon.svg"
                />
              </div>
            </div>
          </div>
        </div>

        <p className="text-wrapper-45">
          Finalised, content-rich screens built from templates. These are what
          the learner experiences—like intros, scenarios, quizzes, and result
          screens.
        </p>

        <div className="card-atoms-2">
          <div className="rectangle-52" />

          <div className="frame-48">
            <div className="header-35">Pages</div>

            <p className="header-36">
              Finalised screens using real content, derived from templates.
            </p>
          </div>
        </div>

        <div className="rectangle-53" />

        <div className="group-41">
          <div className="group-42">
            <div className="bg-icon-6" />

            <div className="bg-icon-7" />

            <div className="bg-icon-8" />
          </div>

          <div className="light-mode">
            <div className="typography-light">
              <div className="property-h">
                <div className="text-wrapper-46">H1</div>
              </div>

              <div className="property-helper" />

              <div className="property-tooltip">
                <div className="text">{""}</div>
              </div>
            </div>
          </div>

          <div className="dark-mode-typography">
            <div className="typography-dark">
              <div className="property-h">
                <div className="text-wrapper-47">H1</div>
              </div>
            </div>
          </div>

          <div className="btn-bg-secondary">
            <div className="bg-icon-primary">
              <div className="rectangle-54" />
            </div>

            <div className="bg-icon-base-default">
              <div className="rectangle-55" />
            </div>

            <div className="bg-icon-base-default-2">
              <div className="rectangle-55" />
            </div>

            <div className="bg-icon-base-default-3">
              <div className="rectangle-55" />
            </div>

            <div className="bg-icon-base-default-4">
              <div className="rectangle-55" />
            </div>
          </div>

          <div className="btn-bg-primary">
            <div className="bg-icon-primary-2" />

            <div className="bg-icon-primary-3" />

            <div className="bg-icon-primary-down" />

            <div className="bg-icon-primary-4" />

            <div className="bg-icon-primary-5" />
          </div>

          <div className="card-3">
            <div className="overlap-group-21">
              <img
                className="rectangle-56"
                alt="Rectangle"
                src="/img/rectangle-132.svg"
              />
            </div>
          </div>

          <div className="img-placeholder-2">
            <div className="overlap-44">
              <img className="line-16" alt="Line" src="/img/line-5.svg" />

              <img className="line-17" alt="Line" src="/img/line-6.svg" />
            </div>
          </div>

          <div className="line-lineline-4">
            <img className="line-18" alt="Line" src="/img/line-65-4.svg" />
          </div>

          <div className="line-small-secondary">
            <div className="line-lineline-5">
              <img className="line-18" alt="Line" src="/img/line-65-5.svg" />
            </div>
          </div>

          <div className="icons-4">
            <Vector56 className="vector-36" />
            <IconDownload1 className="icon-download-1-instance" />
            <IconMore className="icon-more-2" />
          </div>
        </div>
      </div>
    </div>
  );
};
