import React from "react";
import { ColorKeySizeMedium2 } from "../../icons/ColorKeySizeMedium2";
import "./style.css";

export const Buttons = () => {
  return (
    <div className="buttons">
      <div className="div-36">
        <div className="divider-43">
          <img
            className="devider-horizon-43"
            alt="Devider horizon"
            src="/img/devider-horizon-9.png"
          />
        </div>

        <div className="frame-69">
          <div className="header-67">Licence</div>

          <p className="header-68">License information is on the last page.</p>
        </div>

        <div className="page-footer-22">
          <div className="credit-22">
            <div className="text-wrapper-124">© Glenn Hammond</div>
          </div>
        </div>

        <div className="page-title-22">
          <div className="title-44">
            <div className="title-45">Buttons</div>
          </div>
        </div>

        <div className="rectangle-116" />

        <div className="section-meta-22">
          <div className="text-wrapper-125">Contents</div>
        </div>

        <img className="image" alt="Image" src="/img/image-1.png" />

        <div className="btn-6">
          <div className="color-primary-state" />

          <div className="color-primary-state-2" />

          <div className="color-primary-state-3">
            <div className="rectangle-117" />
          </div>

          <div className="color-base-state">
            <div className="rectangle-118" />
          </div>

          <div className="color-base-state-2">
            <div className="rectangle-118" />
          </div>

          <div className="color-base-state-3">
            <div className="rectangle-118" />
          </div>

          <div className="color-base-state-4">
            <div className="rectangle-118" />
          </div>

          <div className="color-primary-state-4" />

          <div className="color-primary-state-5" />

          <div className="color-primary-state-6" />

          <div className="color-primary-state-7" />

          <div className="color-primary-state-8" />

          <div className="color-primary-state-9" />

          <div className="color-primary-state-10" />

          <div className="color-primary-state-11" />
        </div>

        <div className="nav-top">
          <div className="overlap-group-36">
            <img
              className="rectangle-119"
              alt="Rectangle"
              src="/img/rectangle-244.svg"
            />

            <div className="nav-top-btn">
              <div className="typography-35">
                <div className="body-5">Your Role</div>
              </div>
            </div>

            <div className="nav-top-btn-2">
              <div className="typography-35">
                <div className="body-6">Indicators of Harm</div>
              </div>
            </div>

            <div className="nav-top-btn-3">
              <div className="typography-35">
                <div className="body-7">Legal Responsibilities</div>
              </div>
            </div>

            <div className="nav-top-btn-4">
              <div className="typography-35">
                <div className="body-8">Report or Refer</div>
              </div>
            </div>

            <img className="line-24" alt="Line" src="/img/line-115.svg" />

            <img className="line-25" alt="Line" src="/img/line-115.svg" />

            <img className="line-26" alt="Line" src="/img/line-115.svg" />
          </div>

          <img
            className="icon-more-5"
            alt="Icon more"
            src="/img/vector-19.png"
          />
        </div>

        <div className="icon-arrow-left-wrapper">
          <ColorKeySizeMedium2
            className="icon-arrow-left-4-instance"
            color="white"
          />
        </div>

        <div className="overlap-69">
          <img
            className="icon-arrow-left-6"
            alt="Icon arrow left"
            src="/img/icon-arrow-left-5.svg"
          />
        </div>

        <div className="btn-7" />

        <div className="btn-8" />

        <div className="btn-9" />

        <div className="btn-10" />

        <div className="btn-11" />

        <div className="group-75">
          <div className="typography-36">
            <div className="heading-18">MORE</div>
          </div>

          <ColorKeySizeMedium2 className="icon-arrow-left-7" color="white" />
        </div>

        <button className="btn-back">
          <div className="group-76">
            <div className="overlap-group-37">
              <div className="typography-37">
                <div className="heading-19">BACK</div>
              </div>

              <img
                className="icon-arrow-left-8"
                alt="Icon arrow left"
                src="/img/icon-arrow-left-7.svg"
              />

              <div className="btn-primary-default" />
            </div>
          </div>
        </button>

        <div className="group-77">
          <div className="typography-38">
            <div className="heading-20">MORE</div>
          </div>

          <img
            className="icon-arrow-left-9"
            alt="Icon arrow left"
            src="/img/color-base-size-small-3.svg"
          />
        </div>
      </div>
    </div>
  );
};
