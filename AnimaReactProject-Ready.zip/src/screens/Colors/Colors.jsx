import React from "react";
import "./style.css";

export const Colors = () => {
  return (
    <div className="colors">
      <div className="div-29">
        <div className="overlap-63">
          <div className="div-30" />

          <div className="div-31" />

          <div className="page-title-18">
            <div className="title-36">
              <div className="title-37">🎨 Colours</div>
            </div>
          </div>

          <p className="text-wrapper-85">
            Express hierarchy, establish brand identity, give meaning, and
            indicate element states.
          </p>

          <div className="section-header">
            <div className="header-56">Black &amp; White</div>
          </div>

          <div className="neutral">
            <div className="black">
              <div className="frame-54">
                <img
                  className="rectangle-71"
                  alt="Rectangle"
                  src="/img/rectangle.svg"
                />

                <div className="frame-55">
                  <div className="gray">Black</div>

                  <div className="element">#000000</div>
                </div>
              </div>
            </div>

            <div className="div-32">
              <img
                className="rectangle-71"
                alt="Rectangle"
                src="/img/rectangle-1.svg"
              />

              <div className="frame-55">
                <div className="gray">White</div>

                <div className="element">#FFFFFF</div>
              </div>
            </div>
          </div>

          <div className="section-header-2">
            <div className="header-56">Neutral colours</div>

            <p className="text-6">
              Neutral colours can be used with any brand colour.
            </p>
          </div>

          <div className="neutral-2">
            <div className="div-32">
              <div className="rectangle-72" />

              <div className="frame-55">
                <div className="gray">Neutral 700</div>

                <div className="element">#1F1F1F</div>
              </div>
            </div>

            <div className="div-32">
              <div className="group-60" />

              <div className="frame-56">
                <div className="gray">Neutral 600</div>

                <div className="element">#4B4B4B</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-73" />

              <div className="frame-55">
                <div className="gray">Neutral 500</div>

                <div className="element">#8E8E8E</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-74" />

              <div className="frame-55">
                <div className="gray">Neutral 400</div>

                <div className="element">#CACACA</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-75" />

              <div className="frame-55">
                <div className="gray">Neutral 300</div>

                <div className="element">#E1E1E1</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-76" />

              <div className="frame-55">
                <div className="gray">Neutral 200</div>

                <div className="element">#EEEEEE</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-77" />

              <div className="frame-55">
                <div className="gray">Neutral 100</div>

                <div className="element">#F5F5F5</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-78" />

              <div className="frame-55">
                <div className="gray">Neutral 50</div>

                <div className="element">#FAFAFA</div>
              </div>
            </div>
          </div>

          <div className="header-wrapper">
            <div className="header-56">Primary colours</div>
          </div>

          <div className="primary">
            <div className="div-32">
              <img
                className="rectangle-71"
                alt="Rectangle"
                src="/img/rectangle-2.svg"
              />

              <div className="frame-55">
                <div className="gray">Primary</div>

                <div className="element">#005680</div>
              </div>
            </div>

            <div className="div-32">
              <div className="group-61" />

              <div className="frame-55">
                <div className="gray">Primary 80</div>

                <div className="element">#15C5CE</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-79" />

              <div className="frame-55">
                <div className="gray">Primary 60</div>

                <div className="element">#47CFD6</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-80" />

              <div className="frame-55">
                <div className="gray">Primary 40</div>

                <div className="element">#7DDDE1</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-81" />

              <div className="frame-55">
                <div className="gray">Primary 20</div>

                <div className="element">#B0EBEC</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-82" />

              <div className="frame-55">
                <div className="gray">Primary 10</div>

                <div className="element">#DFF7F7</div>
              </div>
            </div>
          </div>

          <div className="section-header-3">
            <div className="header-56">Secondary colours</div>
          </div>

          <div className="section-header-4">
            <div className="header-56">Tertiary colours</div>
          </div>

          <div className="auxiliary">
            <div className="div-32">
              <img
                className="rectangle-71"
                alt="Rectangle"
                src="/img/rectangle-3.svg"
              />

              <div className="frame-55">
                <div className="gray">Secondary</div>

                <div className="element">#FFC72A</div>
              </div>
            </div>

            <div className="div-32">
              <div className="group-62" />

              <div className="frame-55">
                <div className="gray">Secondary</div>

                <div className="element">#FF8156</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-83" />

              <div className="frame-55">
                <div className="gray">Secondary</div>

                <div className="element">#FFA487</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-84" />

              <div className="frame-55">
                <div className="gray">Secondary</div>

                <div className="element">#FFC8B6</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-85" />

              <div className="frame-55">
                <div className="gray">Secondary</div>

                <div className="element">#FFE1D6</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-86" />

              <div className="frame-55">
                <div className="gray">Secondary</div>

                <div className="element">#FFF2EE</div>
              </div>
            </div>
          </div>

          <div className="auxiliary-2">
            <div className="div-32">
              <img
                className="rectangle-71"
                alt="Rectangle"
                src="/img/rectangle-4.svg"
              />

              <div className="frame-55">
                <div className="gray">Tertiary</div>

                <div className="element">#DAD3C5</div>
              </div>
            </div>

            <div className="div-32">
              <div className="group-63" />

              <div className="frame-55">
                <div className="gray">Tertiary</div>

                <div className="element">#FF8156</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-87" />

              <div className="frame-55">
                <div className="gray">Tertiary</div>

                <div className="element">#FFA487</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-88" />

              <div className="frame-55">
                <div className="gray">Tertiary</div>

                <div className="element">#FFC8B6</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-89" />

              <div className="frame-55">
                <div className="gray">Tertiary</div>

                <div className="element">#FFE1D6</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-90" />

              <div className="frame-55">
                <div className="gray">Tertiary</div>

                <div className="element">#FFF2EE</div>
              </div>
            </div>
          </div>

          <div className="section-header-5">
            <div className="header-57">Semantic colours</div>

            <p className="text-6">Semantic colours have designated meanings.</p>
          </div>

          <div className="section-header-6">
            <div className="header-58">Error</div>

            <p className="text-6">
              <span className="text-wrapper-86">Usually indicates </span>

              <span className="text-wrapper-87">dangerous</span>

              <span className="text-wrapper-86">, </span>

              <span className="text-wrapper-87">wrong</span>

              <span className="text-wrapper-86">, or </span>

              <span className="text-wrapper-87">rejected</span>

              <span className="text-wrapper-86"> information.</span>
            </p>
          </div>

          <div className="danger">
            <div className="div-32">
              <img
                className="rectangle-71"
                alt="Rectangle"
                src="/img/rectangle-5.svg"
              />

              <div className="frame-55">
                <div className="gray">Error</div>

                <div className="element">#A22B2A</div>
              </div>
            </div>

            <div className="div-32">
              <div className="group-64" />

              <div className="frame-55">
                <div className="gray">Danger 600</div>

                <div className="element">#F64C4C</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-91" />

              <div className="frame-55">
                <div className="gray">Danger 500</div>

                <div className="element">#EB6F70</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-92" />

              <div className="frame-55">
                <div className="gray">Danger 400</div>

                <div className="element">#F49898</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-93" />

              <div className="frame-55">
                <div className="gray">Danger 300</div>

                <div className="element">#FFCCD2</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-94" />

              <div className="frame-55">
                <div className="gray">Danger 200</div>

                <div className="element">#FFEBEE</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-95" />

              <div className="frame-55">
                <div className="gray">Danger 100</div>

                <div className="element">#FEF2F2</div>
              </div>
            </div>

            <div className="div-32">
              <img
                className="rectangle-71"
                alt="Rectangle"
                src="/img/rectangle-6.svg"
              />

              <div className="frame-55">
                <div className="gray">Danger 50</div>

                <div className="element">#FFFBFB</div>
              </div>
            </div>
          </div>

          <div className="section-header-7">
            <div className="header-58">Warning</div>

            <p className="text-6">
              <span className="text-wrapper-86">Usually indicates </span>

              <span className="text-wrapper-87">warning</span>

              <span className="text-wrapper-86">, </span>

              <span className="text-wrapper-87">progressing</span>

              <span className="text-wrapper-86">, etc.</span>
            </p>
          </div>

          <div className="warning">
            <div className="div-32">
              <img
                className="rectangle-71"
                alt="Rectangle"
                src="/img/rectangle-7.svg"
              />

              <div className="frame-55">
                <div className="gray">Warning</div>

                <div className="element">#F28B00</div>
              </div>
            </div>

            <div className="element-2">
              <div className="group-65" />

              <div className="frame-55">
                <div className="gray">Warning 80</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-96" />

              <div className="frame-55">
                <div className="gray">Warning 60</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-97" />

              <div className="frame-55">
                <div className="gray">Warning 40</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-98" />

              <div className="frame-55">
                <div className="gray">Warning 20</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-99" />

              <div className="frame-55">
                <div className="gray">Warning 10</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-100" />

              <div className="frame-55">
                <div className="gray">Warning 100</div>
              </div>
            </div>

            <div className="div-32">
              <img
                className="rectangle-71"
                alt="Rectangle"
                src="/img/rectangle-8.svg"
              />

              <div className="frame-55">
                <div className="gray">Warning 50</div>
              </div>
            </div>
          </div>

          <div className="section-header-8">
            <div className="header-58">Success</div>

            <p className="text-6">
              <span className="text-wrapper-86">Usually indicates </span>

              <span className="text-wrapper-87">success</span>

              <span className="text-wrapper-86">, </span>

              <span className="text-wrapper-87">correct</span>

              <span className="text-wrapper-86">, </span>

              <span className="text-wrapper-87">passed</span>

              <span className="text-wrapper-86">, etc.</span>
            </p>
          </div>

          <div className="success">
            <div className="div-32">
              <img
                className="rectangle-71"
                alt="Rectangle"
                src="/img/rectangle-9.svg"
              />

              <div className="frame-55">
                <div className="gray">Success</div>

                <div className="element">#38B449</div>
              </div>
            </div>

            <div className="div-32">
              <div className="group-66" />

              <div className="frame-55">
                <div className="gray">Success 600</div>

                <div className="element">#47B881</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-101" />

              <div className="frame-55">
                <div className="gray">Success 500</div>

                <div className="element">#6BC497</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-102" />

              <div className="frame-55">
                <div className="gray">Success 400</div>

                <div className="element">#97D4B4</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-103" />

              <div className="frame-55">
                <div className="gray">Success 300</div>

                <div className="element">#C0E5D1</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-104" />

              <div className="frame-55">
                <div className="gray">Success 200</div>

                <div className="element">#E5F5EC</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-105" />

              <div className="frame-55">
                <div className="gray">Success 100</div>

                <div className="element">#F2FAF6</div>
              </div>
            </div>

            <div className="div-32">
              <img
                className="rectangle-71"
                alt="Rectangle"
                src="/img/rectangle-10.svg"
              />

              <div className="frame-55">
                <div className="gray">Success 50</div>

                <div className="element">#FBFEFC</div>
              </div>
            </div>
          </div>

          <div className="section-header-9">
            <div className="header-58">Info</div>

            <p className="text-6">
              <span className="text-wrapper-86">Usually indicates </span>

              <span className="text-wrapper-87">info</span>

              <span className="text-wrapper-86">, </span>

              <span className="text-wrapper-87">no emotion</span>

              <span className="text-wrapper-86">.</span>
            </p>
          </div>

          <div className="infor">
            <div className="div-32">
              <img
                className="rectangle-71"
                alt="Rectangle"
                src="/img/rectangle-11.svg"
              />

              <div className="frame-55">
                <div className="gray">Info</div>

                <div className="element-3">#1967D2</div>
              </div>
            </div>

            <div className="div-32">
              <div className="group-67">
                <div className="overlap-group-32">
                  <div className="text-wrapper-88">P</div>
                </div>
              </div>

              <div className="frame-55">
                <div className="gray">Info 600</div>

                <div className="element-4">#3B82F6</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-106" />

              <div className="frame-55">
                <div className="gray">Info 500</div>

                <div className="element">#4BA1FF</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-107" />

              <div className="frame-55">
                <div className="gray">Info 400</div>

                <div className="element">#93C8FF</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-108" />

              <div className="frame-55">
                <div className="gray">Info 300</div>

                <div className="element">#BDDDFF</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-109" />

              <div className="frame-55">
                <div className="gray">Info 200</div>

                <div className="element">#E4F2FF</div>
              </div>
            </div>

            <div className="div-32">
              <div className="rectangle-110" />

              <div className="frame-55">
                <div className="gray">Info 100</div>

                <div className="element">#F1F8FF</div>
              </div>
            </div>

            <div className="div-32">
              <img
                className="rectangle-71"
                alt="Rectangle"
                src="/img/rectangle-12.svg"
              />

              <div className="frame-55">
                <div className="gray">Info 50</div>

                <div className="element">#F8FCFF</div>
              </div>
            </div>
          </div>
        </div>

        <div className="divider-38">
          <img
            className="devider-horizon-38"
            alt="Devider horizon"
            src="/img/devider-horizon-9.png"
          />
        </div>

        <div className="frame-57">
          <div className="header-59">Licence</div>

          <p className="header-60">License information is on the last page.</p>
        </div>

        <div className="page-footer-18">
          <div className="credit-18">
            <div className="text-wrapper-89">© Glenn Hammond</div>
          </div>
        </div>

        <div className="rectangle-111" />

        <div className="section-meta-18">
          <div className="text-wrapper-90">Contents</div>
        </div>
      </div>
    </div>
  );
};
