import React from "react";
import { Link } from "react-router-dom";
import { IconDownload1 } from "../../icons/IconDownload1";
import { IconMore } from "../../icons/IconMore";
import { LineLdown3 } from "../../icons/LineLdown3";
import { Vector56 } from "../../icons/Vector56";
import "./style.css";

export const Contents = () => {
  return (
    <div className="contents">
      <div className="div-4">
        <div className="overlap-15">
          <div className="page-title-3">
            <div className="title-6">
              <div className="title-7">Contents</div>
            </div>
          </div>

          <img
            className="devider-horizon-4"
            alt="Devider horizon"
            src="/img/devider-horizon-28.svg"
          />
        </div>

        <div className="page-header-3">
          <div className="section-meta-3">
            <div className="text-wrapper-8">Contents</div>
          </div>

          <Link className="section-meta-3" to="/documentation">
            <div className="text-wrapper-8">Documentation</div>
          </Link>

          <Link className="section-meta-3" to="/design">
            <div className="text-wrapper-8">Design</div>
          </Link>

          <Link className="section-meta-3" to="/development">
            <div className="text-wrapper-8">Development</div>
          </Link>

          <div className="logo-3" />
        </div>

        <div className="page-footer-3">
          <div className="credit-3">
            <div className="text-wrapper-9">© Glenn Hammond</div>
          </div>
        </div>

        <div className="overlap-16">
          <div className="divider-5">
            <img
              className="devider-horizon-5"
              alt="Devider horizon"
              src="/img/devider-horizon.svg"
            />
          </div>

          <div className="group-16">
            <div className="row-docs">
              <Link className="title-doc-4" to="/documentation">
                <div className="header-7">Documentation</div>

                <p className="header-8">
                  Key project records, guidelines, and references.
                </p>
              </Link>

              <div className="divider-6">
                <img
                  className="devider-horizon-5"
                  alt="Devider horizon"
                  src="/img/devider-horizon.svg"
                />
              </div>

              <Link className="frame-26" to="/atomic-design">
                <div className="div-5">
                  <img
                    className="layer-3"
                    alt="Layer"
                    src="/img/layer-1-7.svg"
                  />
                </div>

                <div className="frame-27">
                  <div className="header-9">Atomic Design</div>

                  <div className="header-10">90 components</div>
                </div>
              </Link>

              <Link className="frame-28" to="/elearning-design-system-overview">
                <div className="div-5">
                  <div className="layer-4">
                    <div className="overlap-group-6">
                      <div className="group-17">
                        <img
                          className="group-18"
                          alt="Group"
                          src="/img/group-3.png"
                        />
                      </div>

                      <img
                        className="group-19"
                        alt="Group"
                        src="/img/group-2.png"
                      />
                    </div>
                  </div>
                </div>

                <div className="frame-27">
                  <div className="header-9">
                    eLearning Design System Overview
                  </div>

                  <div className="header-10">324 components</div>
                </div>
              </Link>
            </div>

            <div className="row-design">
              <div className="divider-6">
                <img
                  className="devider-horizon-5"
                  alt="Devider horizon"
                  src="/img/devider-horizon.svg"
                />
              </div>

              <Link className="title-doc-4" to="/design">
                <div className="header-7">Design</div>

                <p className="header-8">
                  Visual layouts, styles, and user interface planning.
                </p>
              </Link>

              <div className="frame-29">
                <div className="div-5" />

                <div className="frame-27">
                  <div className="header-9">Rise</div>

                  <div className="header-10">90 components</div>
                </div>
              </div>

              <Link className="asset-inventory-2" to="/asset-inventory">
                <div className="div-5" />

                <div className="frame-27">
                  <div className="header-9">Asset Inventory</div>

                  <div className="header-10">78 styles</div>
                </div>

                <img
                  className="vector-17"
                  alt="Vector"
                  src="/img/vector-19.png"
                />
              </Link>

              <Link className="storyboard" to="/course-structure">
                <div className="div-5" />

                <div className="frame-27">
                  <div className="header-9">Course Structure</div>

                  <div className="header-10">324 components</div>
                </div>
              </Link>

              <Link className="frame-30" to="/core-more-u38-bore">
                <div className="div-5">
                  <div className="icon-core-more-bore">
                    <div className="overlap-group-7">
                      <div className="rectangle-19" />
                    </div>
                  </div>
                </div>

                <div className="frame-27">
                  <div className="header-11">Core More Bore</div>

                  <div className="header-10">78 styles</div>
                </div>
              </Link>
            </div>

            <div className="row-assets-3">
              <div className="divider-6">
                <img
                  className="devider-horizon-5"
                  alt="Devider horizon"
                  src="/img/devider-horizon.svg"
                />
              </div>

              <div className="title-doc-5">
                <div className="header-7">Assets</div>

                <p className="header-8">
                  Images, media, and content files prepared for use.
                </p>
              </div>

              <div className="div-6">
                <div className="div-5">
                  <div className="typography-14">
                    <div className="overlap-group-8">
                      <img
                        className="line-4"
                        alt="Line"
                        src="/img/line-1-1.svg"
                      />

                      <img
                        className="line-5"
                        alt="Line"
                        src="/img/line-4-1.svg"
                      />

                      <img
                        className="line-6"
                        alt="Line"
                        src="/img/line-1-1.svg"
                      />

                      <img
                        className="line-7"
                        alt="Line"
                        src="/img/line-1-1.svg"
                      />

                      <div className="text-wrapper-10">Aa</div>
                    </div>
                  </div>
                </div>

                <div className="frame-27">
                  <a
                    className="header-12"
                    href="https://www.figma.com/design/1dRIYueVCwnBJZ3ciZyueJ?node-id=2100-12473"
                    rel="noopener noreferrer"
                    target="_blank"
                  >
                    Typography
                  </a>

                  <div className="header-10">14 styles</div>
                </div>
              </div>

              <div className="card-icons">
                <div className="div-5">
                  <div className="icons-2">
                    <Vector56 className="vector-56" />
                    <IconDownload1 className="icon-download" />
                    <IconMore className="icon-more" />
                  </div>
                </div>

                <div className="frame-27">
                  <p className="header-9">
                    <a
                      href="https://www.figma.com/design/1dRIYueVCwnBJZ3ciZyueJ?node-id=2105-13582"
                      rel="noopener noreferrer"
                      target="_blank"
                    >
                      <span className="span">Icon</span>
                    </a>

                    <span className="text-wrapper-11">s</span>
                  </p>

                  <div className="header-10">121 icons</div>
                </div>
              </div>

              <div className="div-7">
                <div className="div-5">
                  <div className="group-20">
                    <div className="overlap-group-9">
                      <img
                        className="rectangle-20"
                        alt="Rectangle"
                        src="/img/rectangle-3467559-1.svg"
                      />

                      <img
                        className="rectangle-21"
                        alt="Rectangle"
                        src="/img/rectangle-3467558-1.svg"
                      />

                      <img
                        className="rectangle-22"
                        alt="Rectangle"
                        src="/img/rectangle-3467557-1.svg"
                      />

                      <div className="ellipse-10" />
                    </div>
                  </div>
                </div>

                <div className="frame-27">
                  <p className="header-9">
                    <a
                      href="https://www.figma.com/design/1dRIYueVCwnBJZ3ciZyueJ?node-id=2100-12472"
                      rel="noopener noreferrer"
                      target="_blank"
                    >
                      <span className="span">Colour</span>
                    </a>

                    <span className="text-wrapper-11">s</span>
                  </p>

                  <div className="header-10">78 styles</div>
                </div>
              </div>
            </div>

            <div className="row-development-2">
              <div className="divider-6">
                <img
                  className="devider-horizon-5"
                  alt="Devider horizon"
                  src="/img/devider-horizon.svg"
                />
              </div>

              <Link className="title-doc-4" to="/development">
                <div className="header-7">Development</div>

                <p className="header-8">
                  Build process, coding, and technical implementation.
                </p>
              </Link>

              <Link className="card-rise-2" to="/rise">
                <div className="div-5">
                  <div className="layer-5">
                    <div className="group-21">
                      <img
                        className="group-22"
                        alt="Group"
                        src="/img/group-427318232-2.png"
                      />

                      <img
                        className="vector-18"
                        alt="Vector"
                        src="/img/vector-38-2.svg"
                      />

                      <img
                        className="vector-19"
                        alt="Vector"
                        src="/img/vector-39.svg"
                      />

                      <img
                        className="vector-20"
                        alt="Vector"
                        src="/img/vector-40-2.svg"
                      />

                      <img
                        className="vector-21"
                        alt="Vector"
                        src="/img/vector-61-2.svg"
                      />

                      <img
                        className="vector-22"
                        alt="Vector"
                        src="/img/vector-42.svg"
                      />

                      <img
                        className="vector-23"
                        alt="Vector"
                        src="/img/vector-63-2.svg"
                      />

                      <img
                        className="vector-24"
                        alt="Vector"
                        src="/img/vector-44.svg"
                      />

                      <img
                        className="vector-25"
                        alt="Vector"
                        src="/img/vector-45.svg"
                      />

                      <img
                        className="vector-26"
                        alt="Vector"
                        src="/img/vector-66.svg"
                      />

                      <img
                        className="vector-27"
                        alt="Vector"
                        src="/img/vector-67.svg"
                      />

                      <img
                        className="vector-28"
                        alt="Vector"
                        src="/img/vector-48-2.svg"
                      />

                      <img
                        className="vector-29"
                        alt="Vector"
                        src="/img/vector-49-2.svg"
                      />

                      <img
                        className="vector-30"
                        alt="Vector"
                        src="/img/vector-50.svg"
                      />

                      <img
                        className="vector-31"
                        alt="Vector"
                        src="/img/vector-51-2.svg"
                      />

                      <img
                        className="vector-32"
                        alt="Vector"
                        src="/img/vector-72.svg"
                      />
                    </div>
                  </div>
                </div>

                <div className="frame-27">
                  <div className="header-9">Rise</div>

                  <div className="header-10">90 components</div>
                </div>
              </Link>

              <Link className="card-2" to="/h5p">
                <div className="div-5">
                  <img
                    className="layer-6"
                    alt="Layer"
                    src="/img/layer-1-8.svg"
                  />
                </div>

                <div className="frame-27">
                  <div className="header-9">H5P</div>

                  <div className="header-10">78 styles</div>
                </div>

                <img
                  className="vector-33"
                  alt="Vector"
                  src="/img/vector-19.png"
                />
              </Link>

              <Link className="card-storyline-2" to="/storyline">
                <div className="div-5">
                  <div className="icon-storyline-2" />
                </div>

                <div className="frame-27">
                  <div className="header-9">Storyline</div>

                  <div className="header-10">324 components</div>
                </div>
              </Link>
            </div>

            <div className="row-navigation-2">
              <div className="title-doc-6">
                <div className="header-7">Navigation</div>

                <p className="header-8">
                  Structure and flow of user interactions.
                </p>
              </div>

              <div className="overlap-17">
                <div className="divider-7">
                  <img
                    className="devider-horizon-5"
                    alt="Devider horizon"
                    src="/img/devider-horizon.svg"
                  />
                </div>

                <div className="card-tabs-2">
                  <div className="div-5">
                    <div className="group-23">
                      <div className="overlap-18">
                        <div className="overlap-group-10">
                          <div className="rectangle-23" />

                          <div className="rectangle-24" />
                        </div>

                        <div className="overlap-19">
                          <div className="rectangle-25" />

                          <div className="rectangle-26" />
                        </div>

                        <div className="rectangle-27" />
                      </div>
                    </div>
                  </div>

                  <div className="frame-31">
                    <a
                      className="header-12"
                      href="https://www.figma.com/design/1dRIYueVCwnBJZ3ciZyueJ?node-id=2129-646"
                      rel="noopener noreferrer"
                      target="_blank"
                    >
                      Tabs
                    </a>

                    <div className="header-10">24 components</div>
                  </div>
                </div>

                <div className="card-accordion-2">
                  <div className="div-5" />

                  <div className="frame-31">
                    <div className="header-9">Accordion</div>

                    <div className="header-10">24 components</div>
                  </div>
                </div>

                <div className="card-buttons-2">
                  <div className="div-5">
                    <div className="group-24">
                      <div className="rectangle-28" />
                    </div>
                  </div>

                  <div className="frame-27">
                    <div className="header-9">Buttons</div>

                    <div className="header-10">324 components</div>
                  </div>
                </div>
              </div>

              <div className="divider-8">
                <img
                  className="devider-horizon-5"
                  alt="Devider horizon"
                  src="/img/devider-horizon.svg"
                />
              </div>
            </div>

            <div className="row-data-2">
              <div className="title-doc-5">
                <div className="header-7">Data Entry</div>

                <p className="header-8">
                  Text, media, and metadata input and formatting.
                </p>
              </div>

              <div className="divider-6">
                <img
                  className="devider-horizon-5"
                  alt="Devider horizon"
                  src="/img/devider-horizon.svg"
                />
              </div>

              <div className="card-form-buttons-3">
                <div className="group-25">
                  <div className="overlap-20">
                    <div className="group-26">
                      <div className="frame-32">
                        <div className="overlap-group-11">
                          <div className="ellipse-11" />
                        </div>

                        <div className="rectangle-29" />
                      </div>

                      <div className="frame-33">
                        <div className="ellipse-12" />

                        <div className="rectangle-30" />
                      </div>

                      <div className="frame-34">
                        <div className="ellipse-12" />

                        <div className="rectangle-30" />
                      </div>
                    </div>
                  </div>

                  <div className="frame-35">
                    <div className="header-9">Form Buttons</div>

                    <div className="header-10">4 components</div>
                  </div>
                </div>
              </div>

              <div className="div-7">
                <div className="group-25">
                  <div className="overlap-20">
                    <div className="group-26">
                      <div className="frame-32">
                        <div className="overlap-group-11">
                          <div className="ellipse-11" />
                        </div>

                        <div className="rectangle-29" />
                      </div>

                      <div className="frame-33">
                        <div className="ellipse-12" />

                        <div className="rectangle-30" />
                      </div>

                      <div className="frame-34">
                        <div className="ellipse-12" />

                        <div className="rectangle-30" />
                      </div>
                    </div>
                  </div>

                  <div className="frame-35">
                    <div className="header-9">Form Buttons</div>

                    <div className="header-10">4 components</div>
                  </div>
                </div>
              </div>

              <div className="div-6">
                <div className="div-5">
                  <div className="group-27">
                    <div className="frame-36">
                      <div className="rectangle-31" />

                      <div className="rectangle-32" />
                    </div>

                    <div className="frame-37">
                      <div className="rectangle-31" />

                      <div className="rectangle-32" />
                    </div>

                    <div className="frame-38">
                      <div className="rectangle-33" />

                      <div className="line-ldown-3-wrapper">
                        <LineLdown3 className="line-ldown-3" />
                      </div>
                    </div>

                    <div className="overlap-21">
                      <div className="rectangle-34" />
                    </div>
                  </div>
                </div>

                <div className="frame-27">
                  <div className="header-9">Form Fields</div>

                  <div className="header-10">2 components</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="rectangle-35" />
      </div>
    </div>
  );
};
