import React from "react";
import { Link } from "react-router-dom";
import "./style.css";

export const CoreMoreBore = () => {
  return (
    <div className="core-more-bore">
      <div className="div-22">
        <div className="overlap-50">
          <div className="page-title-13">
            <div className="title-26">
              <div className="title-27">Core More &amp; Bore</div>
            </div>
          </div>

          <img
            className="devider-horizon-29"
            alt="Devider horizon"
            src="/img/devider-horizon-18.svg"
          />
        </div>

        <div className="page-header-13">
          <Link className="section-meta-13" to="/contents">
            <div className="text-wrapper-61">Contents</div>
          </Link>

          <Link className="section-meta-13" to="/documentation">
            <div className="text-wrapper-61">Documentation</div>
          </Link>

          <Link className="section-meta-13" to="/design">
            <div className="text-wrapper-61">Design</div>
          </Link>

          <Link className="section-meta-13" to="/development">
            <div className="text-wrapper-61">Development</div>
          </Link>

          <div className="logo-13" />
        </div>

        <div className="overlap-51">
          <div className="page-footer-13">
            <div className="credit-13">
              <div className="text-wrapper-62">© Glenn Hammond</div>
            </div>
          </div>

          <div className="group-46">
            <div className="typography-23">
              <div className="heading-10">Tab 1</div>
            </div>

            <div className="typography-24">
              <div className="heading-10">Tab 2</div>
            </div>

            <div className="overlap-52">
              <div className="typography-25">
                <div className="heading-10">Tab 3</div>
              </div>
            </div>

            <div className="typography-26">
              <div className="heading-10">Tab 4</div>
            </div>

            <div className="overlap-53">
              <div className="typography-27">
                <div className="heading-11">Tab Three</div>
              </div>
            </div>
          </div>
        </div>

        <div className="rectangle-63" />

        <div className="overlap-54">
          <div className="divider-28">
            <img
              className="devider-horizon-30"
              alt="Devider horizon"
              src="/img/devider-horizon.svg"
            />
          </div>

          <div className="row-assets-10">
            <div className="row-assets-11">
              <div className="title-doc-16">
                <div className="header-46">Assets</div>

                <p className="header-47">
                  Images, media, and content files prepared for use.
                </p>
              </div>

              <p className="text-wrapper-63">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris
                nisi ut aliquip ex ea commodo consequat.
              </p>

              <div className="divider-29">
                <div className="overlap-group-25">
                  <img
                    className="devider-horizon-30"
                    alt="Devider horizon"
                    src="/img/devider-horizon.svg"
                  />

                  <div className="divider-30">
                    <img
                      className="devider-horizon-30"
                      alt="Devider horizon"
                      src="/img/devider-horizon.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="rectangle-64" />

        <img
          className="group-47"
          alt="Group"
          src="/img/devider-horizon-9.png"
        />
      </div>
    </div>
  );
};
