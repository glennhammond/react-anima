import React from "react";
import { Link } from "react-router-dom";
import "./style.css";

export const CourseStructure = () => {
  return (
    <div className="course-structure">
      <div className="div-23">
        <div className="overlap-55">
          <div className="page-title-14">
            <div className="title-28">
              <div className="title-29">Course Structure</div>
            </div>
          </div>

          <img
            className="devider-horizon-31"
            alt="Devider horizon"
            src="/img/devider-horizon-22.svg"
          />
        </div>

        <div className="page-header-14">
          <Link className="section-meta-14" to="/contents">
            <div className="text-wrapper-64">Contents</div>
          </Link>

          <Link className="section-meta-14" to="/documentation">
            <div className="text-wrapper-64">Documentation</div>
          </Link>

          <Link className="section-meta-14" to="/design">
            <div className="text-wrapper-64">Design</div>
          </Link>

          <Link className="section-meta-14" to="/development">
            <div className="text-wrapper-64">Development</div>
          </Link>

          <div className="logo-14" />
        </div>

        <div className="page-footer-14">
          <div className="credit-14">
            <div className="text-wrapper-65">© Glenn Hammond</div>
          </div>
        </div>

        <div className="rectangle-65" />

        <div className="divider-31">
          <img
            className="devider-horizon-32"
            alt="Devider horizon"
            src="/img/devider-horizon.svg"
          />
        </div>

        <div className="divider-32">
          <img
            className="devider-horizon-33"
            alt="Devider horizon"
            src="/img/devider-horizon-50.svg"
          />
        </div>

        <div className="row-development-6">
          <div className="title-doc-17">
            <div className="header-48">Overview</div>

            <p className="header-49">
              Build process, coding, and technical implementation.
            </p>
          </div>
        </div>

        <div className="group-48">
          <img
            className="ACKNOWLEDGEMENT"
            alt="Acknowledgement"
            src="/img/acknowledgement.svg"
          />

          <img className="START" alt="Start" src="/img/start.svg" />

          <img
            className="SCENARIO"
            alt="Scenario"
            src="/img/scenario-1-4.svg"
          />

          <img
            className="SCENARIO-2"
            alt="Scenario"
            src="/img/scenario-2-4.svg"
          />

          <img
            className="STATISTICS"
            alt="Statistics"
            src="/img/statistics.svg"
          />

          <img
            className="connector-line"
            alt="Connector line"
            src="/img/connector-line.svg"
          />

          <img className="role-a" alt="Role a" src="/img/role-a.svg" />

          <img className="role-b" alt="Role b" src="/img/role-b.svg" />

          <img
            className="shape-with-text"
            alt="Shape with text"
            src="/img/shape-with-text.svg"
          />

          <img className="QUESTION" alt="Question" src="/img/question.svg" />

          <img
            className="this-selection-sets"
            alt="This selection sets"
            src="/img/this-selection-sets-the-context-for-all-following-options-and-de.svg"
          />

          <div className="shape-with-text-wrapper">
            <img
              className="shape-with-text-2"
              alt="Shape with text"
              src="/img/shape-with-text-2.svg"
            />
          </div>

          <img
            className="connector-line-2"
            alt="Connector line"
            src="/img/connector-line.svg"
          />

          <img
            className="connector-line-3"
            alt="Connector line"
            src="/img/connector-line-2.svg"
          />

          <img
            className="connector-line-4"
            alt="Connector line"
            src="/img/connector-line-3.svg"
          />

          <img
            className="connector-line-5"
            alt="Connector line"
            src="/img/connector-line-4.svg"
          />

          <div className="formative">
            <img
              className="shape-with-text-2"
              alt="Shape with text"
              src="/img/shape-with-text-2.svg"
            />
          </div>

          <div className="formative-2">
            <img
              className="shape-with-text-2"
              alt="Shape with text"
              src="/img/shape-with-text-2.svg"
            />
          </div>

          <img
            className="connector-line-6"
            alt="Connector line"
            src="/img/connector-line-5.svg"
          />

          <div className="group-49">
            <img
              className="shape-with-text-3"
              alt="Shape with text"
              src="/img/shape-with-text-8.svg"
            />
          </div>

          <div className="group-50">
            <img
              className="shape-with-text-3"
              alt="Shape with text"
              src="/img/shape-with-text-8.svg"
            />
          </div>

          <div className="frame-50">
            <div className="text-wrapper-66">Role A</div>
          </div>

          <img
            className="connector-line-7"
            alt="Connector line"
            src="/img/connector-line-6.svg"
          />

          <img
            className="connector-line-8"
            alt="Connector line"
            src="/img/connector-line-7.svg"
          />

          <div className="text-wrapper-67">Question</div>

          <div className="btn-sml-examples">
            <div className="overlap-group-26">
              <div className="btn-5">
                <div className="rectangle-66" />
              </div>

              <div className="typography-28">
                <div className="heading-12">xAPI</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
