export { CourseStructure } from "./CourseStructure";
