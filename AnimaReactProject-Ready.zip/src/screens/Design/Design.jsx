import React from "react";
import { Link } from "react-router-dom";
import { IconDownload1 } from "../../icons/IconDownload1";
import { IconMore } from "../../icons/IconMore";
import { Vector56 } from "../../icons/Vector56";
import "./style.css";

export const Design = () => {
  return (
    <div className="design">
      <div className="div-9">
        <div className="overlap-36">
          <div className="page-title-5">
            <div className="title-10">
              <div className="title-11">Design</div>
            </div>
          </div>

          <img
            className="devider-horizon-8"
            alt="Devider horizon"
            src="/img/devider-horizon-18.svg"
          />
        </div>

        <div className="page-header-5">
          <Link className="section-meta-5" to="/contents">
            <div className="text-wrapper-23">Contents</div>
          </Link>

          <Link className="section-meta-5" to="/documentation">
            <div className="text-wrapper-23">Documentation</div>
          </Link>

          <div className="section-meta-5">
            <div className="text-wrapper-23">Design</div>
          </div>

          <Link className="section-meta-5" to="/development">
            <div className="text-wrapper-23">Development</div>
          </Link>

          <div className="logo-5" />
        </div>

        <div className="page-footer-5">
          <div className="credit-5">
            <div className="text-wrapper-24">© Glenn Hammond</div>
          </div>
        </div>

        <div className="rectangle-42" />

        <div className="overlap-37">
          <div className="group-36">
            <div className="row-assets-5">
              <div className="divider-11">
                <img
                  className="devider-horizon-9"
                  alt="Devider horizon"
                  src="/img/devider-horizon.svg"
                />
              </div>

              <div className="title-doc-8">
                <div className="header-17">Assets</div>

                <p className="header-18">
                  Images, media, and content files prepared for use.
                </p>
              </div>

              <div className="card-typography">
                <div className="div-10">
                  <div className="typography-21">
                    <div className="overlap-group-14">
                      <img
                        className="line-12"
                        alt="Line"
                        src="/img/line-1-1.svg"
                      />

                      <img
                        className="line-13"
                        alt="Line"
                        src="/img/line-4-1.svg"
                      />

                      <img
                        className="line-14"
                        alt="Line"
                        src="/img/line-1-1.svg"
                      />

                      <img
                        className="line-15"
                        alt="Line"
                        src="/img/line-1-1.svg"
                      />

                      <div className="text-wrapper-25">Aa</div>
                    </div>
                  </div>
                </div>

                <div className="frame-41">
                  <a
                    className="header-19"
                    href="https://www.figma.com/design/1dRIYueVCwnBJZ3ciZyueJ?node-id=2100-12473"
                    rel="noopener noreferrer"
                    target="_blank"
                  >
                    Typography
                  </a>

                  <div className="header-20">14 styles</div>
                </div>
              </div>

              <div className="card-icons-2">
                <div className="div-10">
                  <div className="icons-3">
                    <Vector56 className="vector-56-instance" />
                    <IconDownload1 className="icon-download-1" />
                    <IconMore className="icon-more-instance" />
                  </div>
                </div>

                <div className="frame-41">
                  <p className="header-21">
                    <a
                      href="https://www.figma.com/design/1dRIYueVCwnBJZ3ciZyueJ?node-id=2105-13582"
                      rel="noopener noreferrer"
                      target="_blank"
                    >
                      <span className="text-wrapper-26">Icon</span>
                    </a>

                    <span className="text-wrapper-27">s</span>
                  </p>

                  <div className="header-20">121 icons</div>
                </div>
              </div>

              <div className="card-colors">
                <div className="div-10">
                  <div className="group-37">
                    <div className="overlap-group-15">
                      <img
                        className="rectangle-43"
                        alt="Rectangle"
                        src="/img/rectangle-3467559-2.svg"
                      />

                      <img
                        className="rectangle-44"
                        alt="Rectangle"
                        src="/img/rectangle-3467558-1.svg"
                      />

                      <img
                        className="rectangle-45"
                        alt="Rectangle"
                        src="/img/rectangle-3467557-2.svg"
                      />

                      <div className="ellipse-14" />
                    </div>
                  </div>
                </div>

                <div className="frame-41">
                  <p className="header-21">
                    <a
                      href="https://www.figma.com/design/1dRIYueVCwnBJZ3ciZyueJ?node-id=2100-12472"
                      rel="noopener noreferrer"
                      target="_blank"
                    >
                      <span className="text-wrapper-26">Colour</span>
                    </a>

                    <span className="text-wrapper-27">s</span>
                  </p>

                  <div className="header-20">78 styles</div>
                </div>
              </div>
            </div>

            <div className="row-design-2">
              <div className="divider-11">
                <img
                  className="devider-horizon-9"
                  alt="Devider horizon"
                  src="/img/devider-horizon.svg"
                />
              </div>

              <div className="title-doc-8">
                <div className="header-17">Design</div>

                <p className="header-18">
                  Visual layouts, styles, and user interface planning.
                </p>
              </div>

              <div className="frame-42">
                <div className="div-10" />

                <div className="frame-41">
                  <div className="header-21">Rise</div>

                  <div className="header-20">90 components</div>
                </div>
              </div>

              <div className="asset-inventory-3">
                <div className="div-10" />

                <div className="frame-41">
                  <div className="header-21">Asset Inventory</div>

                  <div className="header-20">78 styles</div>
                </div>

                <img
                  className="vector-34"
                  alt="Vector"
                  src="/img/vector-19.png"
                />
              </div>

              <div className="storyboard-2">
                <div className="div-10" />

                <div className="frame-41">
                  <div className="header-21">Storyboard</div>

                  <div className="header-20">324 components</div>
                </div>
              </div>
            </div>
          </div>

          <div className="divider-12">
            <img
              className="devider-horizon-9"
              alt="Devider horizon"
              src="/img/devider-horizon.svg"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
