import React from "react";
import { Link } from "react-router-dom";
import { LineLdown3 } from "../../icons/LineLdown3";
import "./style.css";

export const Development = () => {
  return (
    <div className="development">
      <div className="div-2">
        <div className="overlap-9">
          <div className="page-title-2">
            <div className="title-wrapper">
              <div className="title-5">Development</div>
            </div>
          </div>

          <img
            className="devider-horizon-2"
            alt="Devider horizon"
            src="/img/devider-horizon-22.svg"
          />
        </div>

        <div className="page-header-2">
          <Link className="section-meta-2" to="/contents">
            <div className="text-wrapper-6">Contents</div>
          </Link>

          <Link className="section-meta-2" to="/documentation">
            <div className="text-wrapper-6">Documentation</div>
          </Link>

          <Link className="section-meta-2" to="/design">
            <div className="text-wrapper-6">Design</div>
          </Link>

          <Link className="section-meta-2" to="/contents">
            <div className="text-wrapper-6">Development</div>
          </Link>

          <div className="logo-2" />
        </div>

        <div className="page-footer-2">
          <div className="credit-2">
            <div className="text-wrapper-7">© Glenn Hammond</div>
          </div>
        </div>

        <div className="rectangle-6" />

        <div className="img-wrapper">
          <img
            className="devider-horizon-3"
            alt="Devider horizon"
            src="/img/devider-horizon.svg"
          />
        </div>

        <div className="row-development">
          <div className="divider-2">
            <img
              className="devider-horizon-3"
              alt="Devider horizon"
              src="/img/devider-horizon.svg"
            />
          </div>

          <div className="title-doc-2">
            <div className="header-2">Development</div>

            <p className="header-3">
              Build process, coding, and technical implementation.
            </p>
          </div>

          <Link className="card-rise" to="/rise">
            <div className="div-3">
              <div className="layer">
                <div className="group-10">
                  <img
                    className="group-11"
                    alt="Group"
                    src="/img/group-427318232-2.png"
                  />

                  <img
                    className="vector"
                    alt="Vector"
                    src="/img/vector-38-2.svg"
                  />

                  <img
                    className="vector-2"
                    alt="Vector"
                    src="/img/vector-39.svg"
                  />

                  <img
                    className="vector-3"
                    alt="Vector"
                    src="/img/vector-40-2.svg"
                  />

                  <img
                    className="vector-4"
                    alt="Vector"
                    src="/img/vector-41.svg"
                  />

                  <img
                    className="vector-5"
                    alt="Vector"
                    src="/img/vector-42.svg"
                  />

                  <img
                    className="vector-6"
                    alt="Vector"
                    src="/img/vector-43-2.svg"
                  />

                  <img
                    className="vector-7"
                    alt="Vector"
                    src="/img/vector-44.svg"
                  />

                  <img
                    className="vector-8"
                    alt="Vector"
                    src="/img/vector-45.svg"
                  />

                  <img
                    className="vector-9"
                    alt="Vector"
                    src="/img/vector-46-2.svg"
                  />

                  <img
                    className="vector-10"
                    alt="Vector"
                    src="/img/vector-47.svg"
                  />

                  <img
                    className="vector-11"
                    alt="Vector"
                    src="/img/vector-48-2.svg"
                  />

                  <img
                    className="vector-12"
                    alt="Vector"
                    src="/img/vector-49-2.svg"
                  />

                  <img
                    className="vector-13"
                    alt="Vector"
                    src="/img/vector-50.svg"
                  />

                  <img
                    className="vector-14"
                    alt="Vector"
                    src="/img/vector-51-2.svg"
                  />

                  <img
                    className="vector-15"
                    alt="Vector"
                    src="/img/vector-52-2.svg"
                  />
                </div>
              </div>
            </div>

            <div className="frame-17">
              <div className="header-4">Rise</div>

              <div className="header-5">90 components</div>
            </div>
          </Link>

          <Link className="card-hp" to="/h5p">
            <div className="div-3">
              <img className="layer-2" alt="Layer" src="/img/layer-1-5.svg" />
            </div>

            <div className="frame-17">
              <div className="header-4">H5P</div>

              <div className="header-5">78 styles</div>
            </div>

            <img className="vector-16" alt="Vector" src="/img/vector-19.png" />
          </Link>

          <Link className="card-storyline" to="/storyline">
            <div className="div-3">
              <div className="icon-storyline" />
            </div>

            <div className="frame-17">
              <div className="header-4">Storyline</div>

              <div className="header-5">324 components</div>
            </div>
          </Link>
        </div>

        <div className="row-navigation">
          <div className="title-doc-3">
            <div className="header-2">Navigation</div>

            <p className="header-3">Structure and flow of user interactions.</p>
          </div>

          <div className="overlap-10">
            <div className="divider-3">
              <img
                className="devider-horizon-3"
                alt="Devider horizon"
                src="/img/devider-horizon.svg"
              />
            </div>

            <div className="card-tabs">
              <div className="div-3">
                <div className="group-12">
                  <div className="overlap-11">
                    <div className="overlap-12">
                      <div className="rectangle-7" />

                      <div className="rectangle-8" />
                    </div>

                    <div className="overlap-group-4">
                      <div className="rectangle-9" />

                      <div className="rectangle-10" />
                    </div>

                    <div className="rectangle-11" />
                  </div>
                </div>
              </div>

              <div className="frame-18">
                <a
                  className="header-6"
                  href="https://www.figma.com/design/1dRIYueVCwnBJZ3ciZyueJ?node-id=2129-646"
                  rel="noopener noreferrer"
                  target="_blank"
                >
                  Tabs
                </a>

                <div className="header-5">24 components</div>
              </div>
            </div>

            <div className="card-accordion">
              <div className="div-3" />

              <div className="frame-18">
                <div className="header-4">Accordion</div>

                <div className="header-5">24 components</div>
              </div>
            </div>

            <div className="card-buttons">
              <div className="div-3">
                <div className="rectangle-wrapper">
                  <div className="rectangle-12" />
                </div>
              </div>

              <div className="frame-17">
                <div className="header-4">Buttons</div>

                <div className="header-5">324 components</div>
              </div>
            </div>
          </div>

          <div className="divider-4">
            <img
              className="devider-horizon-3"
              alt="Devider horizon"
              src="/img/devider-horizon.svg"
            />
          </div>
        </div>

        <div className="row-data">
          <div className="title-doc-2">
            <div className="header-2">Data Entry</div>

            <p className="header-3">
              Text, media, and metadata input and formatting.
            </p>
          </div>

          <div className="divider-2">
            <img
              className="devider-horizon-3"
              alt="Devider horizon"
              src="/img/devider-horizon.svg"
            />
          </div>

          <div className="card-form-buttons">
            <div className="group-13">
              <div className="overlap-13">
                <div className="group-14">
                  <div className="frame-19">
                    <div className="overlap-group-5">
                      <div className="ellipse-8" />
                    </div>

                    <div className="rectangle-13" />
                  </div>

                  <div className="frame-20">
                    <div className="ellipse-9" />

                    <div className="rectangle-14" />
                  </div>

                  <div className="frame-21">
                    <div className="ellipse-9" />

                    <div className="rectangle-14" />
                  </div>
                </div>
              </div>

              <div className="frame-22">
                <div className="header-4">Form Buttons</div>

                <div className="header-5">4 components</div>
              </div>
            </div>
          </div>

          <div className="card-form-buttons-2">
            <div className="group-13">
              <div className="overlap-13">
                <div className="group-14">
                  <div className="frame-19">
                    <div className="overlap-group-5">
                      <div className="ellipse-8" />
                    </div>

                    <div className="rectangle-13" />
                  </div>

                  <div className="frame-20">
                    <div className="ellipse-9" />

                    <div className="rectangle-14" />
                  </div>

                  <div className="frame-21">
                    <div className="ellipse-9" />

                    <div className="rectangle-14" />
                  </div>
                </div>
              </div>

              <div className="frame-22">
                <div className="header-4">Form Buttons</div>

                <div className="header-5">4 components</div>
              </div>
            </div>
          </div>

          <div className="card-form-fields">
            <div className="div-3">
              <div className="group-15">
                <div className="frame-23">
                  <div className="rectangle-15" />

                  <div className="rectangle-16" />
                </div>

                <div className="frame-24">
                  <div className="rectangle-15" />

                  <div className="rectangle-16" />
                </div>

                <div className="frame-25">
                  <div className="rectangle-17" />

                  <div className="line-ldown-wrapper">
                    <LineLdown3 className="line-ldown" />
                  </div>
                </div>

                <div className="overlap-14">
                  <div className="rectangle-18" />
                </div>
              </div>
            </div>

            <div className="frame-17">
              <div className="header-4">Form Fields</div>

              <div className="header-5">2 components</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
