import React from "react";
import { Link } from "react-router-dom";
import "./style.css";

export const Documentation = () => {
  return (
    <div className="documentation">
      <div className="div-11">
        <div className="overlap-38">
          <div className="page-title-6">
            <div className="title-12">
              <div className="title-13">Documentation</div>
            </div>
          </div>

          <img
            className="devider-horizon-10"
            alt="Devider horizon"
            src="/img/devider-horizon-44.svg"
          />
        </div>

        <div className="page-header-6">
          <Link className="section-meta-6" to="/contents">
            <div className="text-wrapper-28">Contents</div>
          </Link>

          <div className="section-meta-6">
            <div className="text-wrapper-28">Documentation</div>
          </div>

          <Link className="section-meta-6" to="/design">
            <div className="text-wrapper-28">Design</div>
          </Link>

          <Link className="section-meta-6" to="/development">
            <div className="text-wrapper-28">Development</div>
          </Link>

          <div className="logo-6" />
        </div>

        <div className="page-footer-6">
          <div className="credit-6">
            <div className="text-wrapper-29">© Glenn Hammond</div>
          </div>
        </div>

        <div className="row-docs-wrapper">
          <div className="row-docs-2">
            <div className="title-doc-9">
              <div className="header-22">Intro</div>

              <p className="header-23">
                Key project records, guidelines, and references.
              </p>
            </div>

            <div className="divider-13">
              <img
                className="devider-horizon-11"
                alt="Devider horizon"
                src="/img/devider-horizon.svg"
              />
            </div>

            <Link className="frame-43" to="/atomic-design">
              <div className="div-12">
                <img
                  className="layer-7"
                  alt="Layer"
                  src="/img/layer-1-10.svg"
                />
              </div>

              <div className="frame-44">
                <div className="header-24">Atomic Design</div>

                <div className="header-25">90 components</div>
              </div>
            </Link>

            <Link className="frame-45" to="/core-more-u38-bore">
              <div className="div-12">
                <div className="icon-core-more-bore-2">
                  <div className="overlap-group-16">
                    <div className="rectangle-46" />
                  </div>
                </div>
              </div>

              <div className="frame-44">
                <div className="header-26">Core More Bore</div>

                <div className="header-25">78 styles</div>
              </div>
            </Link>

            <Link className="frame-46" to="/elearning-design-system-overview">
              <div className="div-12">
                <div className="layer-8">
                  <div className="overlap-group-17">
                    <div className="group-38">
                      <img
                        className="group-39"
                        alt="Group"
                        src="/img/group-3.png"
                      />
                    </div>

                    <img
                      className="group-40"
                      alt="Group"
                      src="/img/group-4.png"
                    />
                  </div>
                </div>
              </div>

              <div className="frame-44">
                <div className="header-24">
                  eLearning Design System Overview
                </div>

                <div className="header-25">324 components</div>
              </div>
            </Link>

            <div className="divider-14">
              <img
                className="devider-horizon-11"
                alt="Devider horizon"
                src="/img/devider-horizon.svg"
              />
            </div>
          </div>
        </div>

        <div className="rectangle-47" />

        <div className="row-design-3">
          <div className="divider-13">
            <img
              className="devider-horizon-11"
              alt="Devider horizon"
              src="/img/devider-horizon.svg"
            />
          </div>

          <div className="title-doc-9">
            <div className="header-22">Library</div>

            <p className="header-23">
              Visual layouts, styles, and user interface planning.
            </p>
          </div>

          <div className="frame-47">
            <div className="div-12" />

            <div className="frame-44">
              <div className="header-24">xAPI</div>

              <div className="header-25">90 components</div>
            </div>
          </div>

          <Link className="asset-inventory-4" to="/asset-inventory">
            <div className="div-12" />

            <div className="frame-44">
              <div className="header-24">Asset Inventory</div>

              <div className="header-25">78 styles</div>
            </div>

            <img className="vector-35" alt="Vector" src="/img/vector-19.png" />
          </Link>

          <div className="storyboard-3">
            <div className="div-12" />

            <div className="frame-44">
              <div className="header-24">Course Docs</div>

              <div className="header-25">324 components</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
