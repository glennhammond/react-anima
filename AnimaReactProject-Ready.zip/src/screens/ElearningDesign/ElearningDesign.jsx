import React from "react";
import { Link } from "react-router-dom";
import "./style.css";

export const ElearningDesign = () => {
  return (
    <div className="elearning-design">
      <div className="div-21">
        <div className="overlap-group-24">
          <div className="page-title-12">
            <div className="title-24">
              <div className="title-25">eLearning Design System Overview</div>
            </div>
          </div>

          <img
            className="devider-horizon-26"
            alt="Devider horizon"
            src="/img/devider-horizon-22.svg"
          />
        </div>

        <div className="page-header-12">
          <Link className="section-meta-12" to="/contents">
            <div className="text-wrapper-54">Contents</div>
          </Link>

          <Link className="section-meta-12" to="/documentation">
            <div className="text-wrapper-54">Documentation</div>
          </Link>

          <Link className="section-meta-12" to="/design">
            <div className="text-wrapper-54">Design</div>
          </Link>

          <Link className="section-meta-12" to="/development">
            <div className="text-wrapper-54">Development</div>
          </Link>

          <div className="logo-12" />
        </div>

        <div className="page-footer-12">
          <div className="credit-12">
            <div className="text-wrapper-55">© Glenn Hammond</div>
          </div>
        </div>

        <div className="rectangle-62" />

        <div className="divider-26">
          <img
            className="devider-horizon-27"
            alt="Devider horizon"
            src="/img/devider-horizon.svg"
          />
        </div>

        <div className="overlap-49">
          <div className="divider-27">
            <img
              className="devider-horizon-28"
              alt="Devider horizon"
              src="/img/devider-horizon-50.svg"
            />
          </div>

          <p className="element-objectives-enhance">
            <span className="text-wrapper-56">
              1. Objectives 
              <br />
            </span>

            <span className="text-wrapper-57">
              Enhance the UI &amp; UX across eLearning courses.
              <br />
              Standardise the course development process using a reusable design
              system.
              <br />
              Apply a structured content model to present information with
              clarity and impact  
              <br />
            </span>

            <span className="text-wrapper-56">2. Design System Components</span>

            <span className="text-wrapper-58">
              {" "}
              <br />
            </span>

            <span className="text-wrapper-59">
              Visual Identity: 
              <br />
            </span>

            <span className="text-wrapper-57">
              Font pairing: Century Gothic (headings), Open Sans (body)
              <br />
              Consistent colour palette aligned with ISQ branding
              <br />
              Iconography, imagery guidelines, button styles, layout templates
            </span>

            <span className="text-wrapper-57">
              {" "}
              <br />
            </span>

            <span className="text-wrapper-59">
              Functional Templates: 
              <br />
            </span>

            <span className="text-wrapper-57">
              Branded Storyline templates for consistency
              <br />
              Slide templates for intro, summary, case study, interactions,
              knowledge checks
              <br />
              Pre-built Storyline interactions (tabs, click-and-reveal, quizzes)
            </span>

            <span className="text-wrapper-57">
              {" "}
              <br />
            </span>

            <span className="text-wrapper-59">
              UX Principles: 
              <br />
            </span>

            <span className="text-wrapper-57">
              Clear navigation and calls to action
              <br />
              Accessibility considerations
              <br />
              Reduced cognitive load via chunking and visual hierarchy
            </span>

            <span className="text-wrapper-57">
              {" "}
              <br />
            </span>

            <span className="text-wrapper-59">
              Asset Management: 
              <br />
            </span>

            <span className="text-wrapper-57">
              Centralised library of templates and assets in SharePoint or
              Notion
              <br />
              Version control and naming conventions
            </span>

            <span className="text-wrapper-57">
              {" "}
              <br />
              <br />
              <br />
            </span>

            <span className="text-wrapper-56">
              3. Streamlined Development Process
            </span>

            <span className="text-wrapper-58">
              {" "}
              <br />
            </span>

            <span className="text-wrapper-57">
              Central design system = faster production, reduced errors
              <br />
              Shared review and feedback loops with internal stakeholders
              <br />
              QA checklist before publishing
              <br />
              Scalability for future PD areas
              <br />
              Future-ready with support for xAPI tracking and analytics
            </span>

            <span className="text-wrapper-57">
              {" "}
              <br />
              <br />
            </span>

            <span className="text-wrapper-56">
              4. Visual &amp; Instructional Consistency
            </span>

            <span className="text-wrapper-58">
              {" "}
              <br />
            </span>

            <span className="text-wrapper-60">
              Professional course look reinforces credibility and brand
              <br />
              Common structure simplifies learner navigation
              <br />
              Professional delivery reflects industry standard in PD{" "}
            </span>
          </p>
        </div>

        <div className="row-development-5">
          <div className="title-doc-15">
            <div className="header-44">Development</div>

            <p className="header-45">
              Build process, coding, and technical implementation.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
