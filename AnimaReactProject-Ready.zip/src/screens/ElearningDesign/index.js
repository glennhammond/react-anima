export { ElearningDesign } from "./ElearningDesign";
