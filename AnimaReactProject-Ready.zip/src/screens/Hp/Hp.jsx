import React from "react";
import { Link } from "react-router-dom";
import "./style.css";

export const Hp = () => {
  return (
    <div className="hp">
      <div className="div-14">
        <div className="overlap-group-19">
          <div className="page-title-8">
            <div className="title-16">
              <div className="title-17">H5P</div>
            </div>
          </div>

          <img
            className="devider-horizon-15"
            alt="Devider horizon"
            src="/img/devider-horizon-22.svg"
          />
        </div>

        <div className="page-header-8">
          <Link className="section-meta-8" to="/contents">
            <div className="text-wrapper-34">Contents</div>
          </Link>

          <Link className="section-meta-8" to="/documentation">
            <div className="text-wrapper-34">Documentation</div>
          </Link>

          <Link className="section-meta-8" to="/design">
            <div className="text-wrapper-34">Design</div>
          </Link>

          <Link className="section-meta-8" to="/development">
            <div className="text-wrapper-34">Development</div>
          </Link>

          <div className="logo-8" />
        </div>

        <div className="page-footer-8">
          <div className="credit-8">
            <div className="text-wrapper-35">© Glenn Hammond</div>
          </div>
        </div>

        <div className="rectangle-49" />

        <div className="divider-17">
          <img
            className="devider-horizon-16"
            alt="Devider horizon"
            src="/img/devider-horizon.svg"
          />
        </div>

        <div className="overlap-40">
          <div className="divider-18">
            <img
              className="devider-horizon-17"
              alt="Devider horizon"
              src="/img/devider-horizon-50.svg"
            />
          </div>

          <p className="element-title-lorem-ipsum-2">
            <span className="text-wrapper-36">1. Title</span>

            <span className="text-wrapper-37">
              {"  "}Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed
              do eiusmod tempor incididunt ut labore et dolore magna aliqua.
              {"  "}
            </span>
          </p>
        </div>

        <div className="row-development-3">
          <div className="title-doc-11">
            <div className="header-29">Considerations</div>

            <p className="header-30">
              Build process, coding, and technical implementation.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
