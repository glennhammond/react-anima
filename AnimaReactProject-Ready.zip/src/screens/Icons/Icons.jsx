import React from "react";
import { ColorKeySizeMedium2 } from "../../icons/ColorKeySizeMedium2";
import { IconMore } from "../../icons/IconMore";
import "./style.css";

export const Icons = () => {
  return (
    <div className="icons">
      <div className="div-33">
        <div className="divider-39">
          <img
            className="devider-horizon-39"
            alt="Devider horizon"
            src="/img/devider-horizon-9.png"
          />
        </div>

        <div className="frame-58">
          <div className="header-61">Licence</div>

          <p className="header-62">License information is on the last page.</p>
        </div>

        <div className="page-footer-19">
          <div className="credit-19">
            <div className="text-wrapper-91">© Glenn Hammond</div>
          </div>
        </div>

        <div className="page-title-19">
          <div className="title-38">
            <div className="title-39">🎨 Icons</div>
          </div>
        </div>

        <div className="rectangle-112" />

        <div className="section-meta-19">
          <div className="text-wrapper-92">Contents</div>
        </div>

        <div className="icon-close-4">
          <img
            className="color-key-size-small"
            alt="Color key size small"
            src="/img/color-key-size-small.svg"
          />

          <img
            className="color-key-size"
            alt="Color key size"
            src="/img/color-key-size-medium.svg"
          />

          <div className="overlap-group-33">
            <img
              className="color-key-size-large"
              alt="Color key size large"
              src="/img/color-key-size-large-1.png"
            />

            <img
              className="color-base-size"
              alt="Color base size"
              src="/img/color-base-size-large-1.png"
            />

            <img
              className="color-primary-size"
              alt="Color primary size"
              src="/img/color-primary-size-large-1.png"
            />

            <img
              className="color-secondary-size"
              alt="Color secondary size"
              src="/img/color-secondary-size-large-1.png"
            />
          </div>

          <img
            className="color-base-size-2"
            alt="Color base size"
            src="/img/color-base-size-medium.svg"
          />

          <img
            className="color-primary-size-2"
            alt="Color primary size"
            src="/img/color-primary-size-medium.svg"
          />

          <img
            className="color-secondary-size-2"
            alt="Color secondary size"
            src="/img/color-secondary-size-medium.svg"
          />

          <img
            className="color-base-size-3"
            alt="Color base size"
            src="/img/color-base-size-small.svg"
          />

          <img
            className="color-primary-size-3"
            alt="Color primary size"
            src="/img/color-primary-size-small.svg"
          />

          <img
            className="color-secondary-size-3"
            alt="Color secondary size"
            src="/img/color-secondary-size-small.svg"
          />
        </div>

        <div className="btn-radio-16">
          <div className="state-normal" />

          <div className="state-primary-normal" />

          <div className="state-placeholer" />

          <div className="state-selected">
            <div className="ellipse-16" />
          </div>

          <div className="state-primary">
            <div className="ellipse-17" />
          </div>

          <div className="state-placeholdr">
            <div className="ellipse-18" />
          </div>
        </div>

        <div className="icon-arrow-short">
          <div className="size-small-color-key" />

          <div className="size-small-color" />

          <div className="size-small-color-2" />

          <div className="size-small-color-3" />

          <div className="size-small-color-4" />
        </div>

        <div className="icon-pagination">
          <div className="icon-arrow-short-2" />

          <div className="intersect-wrapper">
            <img
              className="intersect"
              alt="Intersect"
              src="/img/intersect-6.svg"
            />
          </div>
        </div>

        <div className="icon-download-3">
          <img
            className="color-key-size-large-2"
            alt="Color key size large"
            src="/img/color-key-size-large.svg"
          />

          <img
            className="color-base-size-4"
            alt="Color base size"
            src="/img/color-base-size-large.svg"
          />

          <img
            className="color-primary-size-4"
            alt="Color primary size"
            src="/img/color-primary-size-large.svg"
          />

          <img
            className="color-secondary-size-4"
            alt="Color secondary size"
            src="/img/color-secondary-size-large.svg"
          />
        </div>

        <div className="icons-pagination">
          <img
            className="img-2"
            alt="Type previous"
            src="/img/type-previous.svg"
          />

          <img className="img-2" alt="Type next" src="/img/type-next.svg" />
        </div>

        <div className="property-primary-wrapper">
          <img
            className="img-3"
            alt="Property primary"
            src="/img/property-1-primary.svg"
          />
        </div>

        <div className="color-secondary-wrapper">
          <img
            className="img-3"
            alt="Color secondary"
            src="/img/color-secondary.svg"
          />
        </div>

        <div className="overlap-64">
          <img
            className="icon-star-base"
            alt="Icon star base"
            src="/img/icon-star-base.png"
          />

          <div className="icon-tick">
            <img className="img-4" alt="Color key" src="/img/color-key.svg" />

            <img
              className="color-base"
              alt="Color base"
              src="/img/color-base.png"
            />

            <img
              className="color-primary"
              alt="Color primary"
              src="/img/color-primary.svg"
            />

            <img
              className="color-secondary"
              alt="Color secondary"
              src="/img/color-secondary-1.svg"
            />

            <img
              className="color-success"
              alt="Color success"
              src="/img/color-success.svg"
            />
          </div>
        </div>

        <div className="icon-more-4">
          <img
            className="color-key-size-small-2"
            alt="Color key size small"
            src="/img/color-key-size-small-orientation-horizontal.svg"
          />

          <img
            className="color-key-size-2"
            alt="Color key size"
            src="/img/color-key-size-medium-orientation-horizontal.svg"
          />

          <IconMore className="color-key-size-large-3" />
          <img
            className="color-key-size-large-4"
            alt="Color key size large"
            src="/img/color-key-size-large-orientation-vertical.svg"
          />

          <img
            className="color-base-size-5"
            alt="Color base size"
            src="/img/color-base-size-large-orientation-vertical.png"
          />

          <img
            className="color-primary-size-5"
            alt="Color primary size"
            src="/img/color-primary-size-large-orientation-vertical.png"
          />

          <img
            className="color-secondary-size-5"
            alt="Color secondary size"
            src="/img/color-secondary-size-large-orientation-vertical.svg"
          />

          <img
            className="color-base-size-6"
            alt="Color base size"
            src="/img/color-base-size-large-orientation-horizontal.svg"
          />

          <img
            className="color-primary-size-6"
            alt="Color primary size"
            src="/img/color-primary-size-large-orientation-horizontal.svg"
          />

          <img
            className="color-base-size-7"
            alt="Color base size"
            src="/img/color-base-size-medium-orientation-horizontal.svg"
          />

          <img
            className="color-key-size-3"
            alt="Color key size"
            src="/img/color-key-size-medium-orientation-vertical.png"
          />

          <img
            className="color-base-size-8"
            alt="Color base size"
            src="/img/color-base-size-medium-orientation-vertical.png"
          />

          <img
            className="color-primary-size-7"
            alt="Color primary size"
            src="/img/color-primary-size-medium-orientation-vertical.png"
          />

          <img
            className="color-secondary-size-6"
            alt="Color secondary size"
            src="/img/color-secondary-size-medium-orientation-vertical.png"
          />

          <img
            className="color-primary-size-8"
            alt="Color primary size"
            src="/img/color-primary-size-medium-orientation-horizontal.svg"
          />

          <img
            className="color-secondary-size-7"
            alt="Color secondary size"
            src="/img/color-secondary-size-medium-orientation-horizontal.svg"
          />

          <img
            className="color-base-size-9"
            alt="Color base size"
            src="/img/color-base-size-small-orientation-horizontal.svg"
          />

          <img
            className="color-primary-size-9"
            alt="Color primary size"
            src="/img/color-primary-size-small-orientation-horizontal.svg"
          />

          <img
            className="color-secondary-size-8"
            alt="Color secondary size"
            src="/img/color-secondary-size-small-orientation-horizontal.svg"
          />

          <img
            className="color-main-size"
            alt="Color main size"
            src="/img/color-main-size-small-orientation-horizontal.svg"
          />

          <img
            className="color-secondary-size-9"
            alt="Color secondary size"
            src="/img/color-secondary-size-large-orientation-horizontal.svg"
          />
        </div>

        <div className="icon-hamburger">
          <img
            className="img-4"
            alt="Color key size small"
            src="/img/color-key-size-small-1.png"
          />

          <img
            className="color-base-size-10"
            alt="Color base size"
            src="/img/color-base-size-small-1.png"
          />

          <img
            className="color-primary-size-10"
            alt="Color primary size"
            src="/img/color-primary-size-small-1.svg"
          />

          <img
            className="color-secondary-size-10"
            alt="Color secondary size"
            src="/img/color-secondary-size-small-1.svg"
          />

          <img
            className="color-accent-size"
            alt="Color accent size"
            src="/img/color-accent-size-small.svg"
          />
        </div>

        <div className="icon-arrow-down">
          <img
            className="color-key-size-small-3"
            alt="Color key size small"
            src="/img/color-key-size-small-2.svg"
          />

          <img
            className="color-key-size-4"
            alt="Color key size"
            src="/img/color-key-size-medium-1.svg"
          />

          <div className="overlap-65">
            <img
              className="color-key-size-large-5"
              alt="Color key size large"
              src="/img/color-key-size-large-2.svg"
            />

            <img
              className="color-base-size-11"
              alt="Color base size"
              src="/img/color-base-size-large-2.svg"
            />

            <img
              className="color-primary-size-11"
              alt="Color primary size"
              src="/img/color-primary-size-large-2.svg"
            />

            <img
              className="color-secondary-size-11"
              alt="Color secondary size"
              src="/img/color-secondary-size-large-2.svg"
            />
          </div>

          <div className="overlap-66">
            <img
              className="color-key-size-medium-2-instance"
              alt="Color base size"
              src="/img/color-base-size-medium-1.svg"
            />

            <img
              className="color-primary-size-12"
              alt="Color primary size"
              src="/img/color-primary-size-medium-1.svg"
            />

            <img
              className="color-secondary-size-12"
              alt="Color secondary size"
              src="/img/color-secondary-size-medium-1.svg"
            />
          </div>

          <img
            className="color-base-size-12"
            alt="Color base size"
            src="/img/color-base-size-small-2.svg"
          />

          <img
            className="color-primary-size-13"
            alt="Color primary size"
            src="/img/color-primary-size-small-2.svg"
          />

          <img
            className="color-secondary-size-13"
            alt="Color secondary size"
            src="/img/color-secondary-size-small-2.svg"
          />
        </div>

        <div className="icon-arrow-left-2">
          <img
            className="color-key-size-small-4"
            alt="Color key size small"
            src="/img/color-key-size-small-3.svg"
          />

          <div className="overlap-67">
            <ColorKeySizeMedium2
              className="color-key-size-medium-2-instance"
              color="black"
            />
            <img
              className="color-base-size-13"
              alt="Color base size"
              src="/img/color-base-size-medium-2.png"
            />

            <img
              className="color-primary-size-14"
              alt="Color primary size"
              src="/img/color-primary-size-medium-2.svg"
            />

            <img
              className="color-secondary-size-14"
              alt="Color secondary size"
              src="/img/color-secondary-size-medium-2.svg"
            />
          </div>

          <div className="overlap-68">
            <img
              className="color-key-size-large-5"
              alt="Color key size large"
              src="/img/color-key-size-large-3.svg"
            />

            <img
              className="color-base-size-14"
              alt="Color base size"
              src="/img/color-base-size-large-3.png"
            />

            <img
              className="color-primary-size-15"
              alt="Color primary size"
              src="/img/color-primary-size-large-3.svg"
            />

            <img
              className="color-secondary-size-15"
              alt="Color secondary size"
              src="/img/color-secondary-size-large-3.svg"
            />
          </div>

          <img
            className="color-base-size-15"
            alt="Color base size"
            src="/img/color-base-size-small-3.svg"
          />

          <img
            className="color-primary-size-16"
            alt="Color primary size"
            src="/img/color-primary-size-small-3.svg"
          />

          <img
            className="color-secondary-size-16"
            alt="Color secondary size"
            src="/img/color-secondary-size-small-3.svg"
          />
        </div>
      </div>
    </div>
  );
};
