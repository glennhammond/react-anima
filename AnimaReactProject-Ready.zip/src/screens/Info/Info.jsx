import React from "react";
import "./style.css";

export const Info = () => {
  return (
    <div className="info">
      <div className="frame-wrapper">
        <div className="frame-51">
          <div className="group-53">
            <div className="overlap-group-28">
              <div className="text-wrapper-73">Actions</div>

              <div className="when-user-clicks-btn-wrapper">
                <p className="div-25">
                  <span className="text-wrapper-74">
                    When user clicks &gt; btn-next &gt;{" "}
                  </span>

                  <span className="text-wrapper-75">jump to next slide </span>
                </p>
              </div>
            </div>
          </div>

          <div className="group-54">
            <div className="overlap-61">
              <div className="text-wrapper-76">Variables</div>

              <div className="when-user-clicks-wrapper">
                <p className="div-25">
                  <span className="text-wrapper-74">
                    When user clicks &gt; principal/board &gt;{" "}
                  </span>

                  <span className="text-wrapper-75">Adjust variable</span>

                  <span className="text-wrapper-74">&nbsp;</span>

                  <span className="text-wrapper-75">userRole</span>
                </p>
              </div>
            </div>
          </div>

          <div className="group-55">
            <div className="group-56">
              <div className="overlap-group-29">
                <div className="text-wrapper-77">Statements</div>

                <div className="storyline-player-wrapper">
                  <p className="storyline-player">
                    // Storyline Player Reference <br />
                    var player = GetPlayer(); <br /> <br />
                    // xAPI Wrapper Setup <br />
                    var lrs = new ADL.XAPIWrapper({"{"} <br />
                    &nbsp;&nbsp;endpoint:
                    &#34;https://your-veracity-endpoint.com/xapi/&#34;, <br />
                    &nbsp;&nbsp;user: &#34;your-lrs-username&#34;, <br />
                    &nbsp;&nbsp;password: &#34;your-lrs-password&#34; <br />
                    {"}"});
                  </p>
                </div>
              </div>
            </div>
          </div>

          <img
            className="icon-close-2"
            alt="Icon close"
            src="/img/icon-close.svg"
          />
        </div>
      </div>
    </div>
  );
};
