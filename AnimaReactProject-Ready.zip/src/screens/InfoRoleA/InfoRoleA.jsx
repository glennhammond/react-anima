import React from "react";
import "./style.css";

export const InfoRoleA = () => {
  return (
    <div className="info-role-a">
      <div className="info-role-a-wrapper">
        <div className="div-26">
          <div className="group-57">
            <div className="group-58">
              <p className="you-are-a-principal">
                <span className="text-wrapper-78">You are a Principal.</span>

                <span className="text-wrapper-79">
                  {" "}
                  In your role, you&#39;re legally required to act on reasonable
                  suspicions of harm. You are the central contact for child
                  protection matters within your school and must ensure
                  mandatory reporting processes are followed.
                </span>
              </p>

              <div className="group-59">
                <div className="overlap-group-30">
                  <p className="download-course">
                    📥 Download Course Companion.pdf
                    <br />
                    Principal Responsibilities
                  </p>

                  <div className="text-wrapper-80">Includes Decision Tree</div>
                </div>
              </div>
            </div>
          </div>

          <img
            className="icon-close-3"
            alt="Icon close"
            src="/img/icon-close-1.svg"
          />
        </div>
      </div>
    </div>
  );
};
