import React from "react";
import { Link } from "react-router-dom";
import { BgIcon1 } from "../../icons/BgIcon1";
import { BgIcon2 } from "../../icons/BgIcon2";
import { Btn3 } from "../../icons/Btn3";
import { Btn4 } from "../../icons/Btn4";
import { Btn5 } from "../../icons/Btn5";
import { ColorKeySizeMedium2 } from "../../icons/ColorKeySizeMedium2";
import { IconArrowLeft1 } from "../../icons/IconArrowLeft1";
import { IconClose } from "../../icons/IconClose";
import "./style.css";

export const Molecules = () => {
  return (
    <div className="molecules">
      <div className="div-8">
        <div className="overlap-22">
          <div className="page-title-4">
            <div className="title-8">
              <div className="title-9">Molecules</div>
            </div>
          </div>

          <img
            className="devider-horizon-6"
            alt="Devider horizon"
            src="/img/devider-horizon-18.svg"
          />
        </div>

        <div className="page-header-4">
          <Link className="section-meta-4" to="/contents">
            <div className="text-wrapper-12">Contents</div>
          </Link>

          <Link className="section-meta-4" to="/documentation">
            <div className="text-wrapper-12">Documentation</div>
          </Link>

          <Link className="section-meta-4" to="/design">
            <div className="text-wrapper-12">Design</div>
          </Link>

          <Link className="section-meta-4" to="/development">
            <div className="text-wrapper-12">Development</div>
          </Link>

          <div className="logo-4" />
        </div>

        <div className="page-footer-4">
          <div className="credit-4">
            <div className="text-wrapper-13">© Glenn Hammond</div>
          </div>
        </div>

        <div className="rectangle-36" />

        <div className="overlap-23">
          <div className="divider-9">
            <img
              className="devider-horizon-7"
              alt="Devider horizon"
              src="/img/devider-horizon.svg"
            />
          </div>

          <div className="row-assets-wrapper">
            <div className="row-assets-4">
              <div className="title-doc-7">
                <div className="header-13">Combinations of Atoms</div>

                <p className="header-14">
                  Images, media, and content files prepared for use.
                </p>
              </div>

              <p className="text-wrapper-14">
                Molecules are simple combinations of atoms working together to
                form functional units. In eLearning, this might be a form
                element composed of a radio button and its label, a progress bar
                with text, or a tooltip with an icon. These small, reusable
                groupings enable consistent UI behaviour and are often used
                across question sets, interactions, and navigation elements such
                as tooltips or modals.
              </p>

              <div className="divider-10">
                <img
                  className="devider-horizon-7"
                  alt="Devider horizon"
                  src="/img/devider-horizon.svg"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="rectangle-37" />

        <div className="group-28">
          <div className="overlap-24">
            <p className="text-wrapper-15">
              Finalised, content-rich screens built from templates. These are
              what the learner experiences—like intros, scenarios, quizzes, and
              result screens.
            </p>

            <div className="card-atoms">
              <div className="rectangle-38" />

              <div className="frame-39">
                <div className="header-15">Pages</div>

                <p className="header-16">
                  Finalised screens using real content, derived from templates.
                </p>
              </div>
            </div>

            <div className="overlap-group-wrapper-2">
              <div className="overlap-25">
                <div className="overlap-group-wrapper-2">
                  <div className="overlap-group-12">
                    <img
                      className="rectangle-39"
                      alt="Rectangle"
                      src="/img/rectangle-132.svg"
                    />
                  </div>
                </div>

                <div className="img-placeholder">
                  <div className="overlap-26">
                    <img className="line-8" alt="Line" src="/img/line-5.svg" />

                    <img className="line-9" alt="Line" src="/img/line-6.svg" />
                  </div>
                </div>
              </div>
            </div>

            <img
              className="rectangle-40"
              alt="Rectangle"
              src="/img/rectangle-131.svg"
            />

            <div className="typography-15">
              <div className="heading-6">Title</div>
            </div>

            <div className="typography-16">
              <p className="body-4">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua.
              </p>
            </div>

            <div className="line-lineline-2">
              <img className="line-10" alt="Line" src="/img/line-65.svg" />
            </div>

            <div className="group-29">
              <div className="overlap-27">
                <div className="btn-wrapper">
                  <Btn4 className="icon-instance-node" />
                </div>

                <div className="text-wrapper-16">Next</div>
              </div>

              <div className="overlap-28">
                <div className="btn-wrapper">
                  <Btn5 className="icon-instance-node" />
                </div>

                <div className="text-wrapper-17">Skip</div>
              </div>
            </div>
          </div>

          <div className="numbers">
            <div className="property">
              <div className="text-wrapper-18">1</div>
            </div>

            <div className="property-variant">
              <div className="text-wrapper-18">7</div>
            </div>

            <div className="property-2">
              <div className="text-wrapper-18">2</div>
            </div>

            <div className="property-3">
              <div className="text-wrapper-18">8</div>
            </div>

            <div className="property-4">
              <div className="text-wrapper-18">3</div>
            </div>

            <div className="property-5">
              <div className="text-wrapper-18">9</div>
            </div>

            <div className="property-6">
              <div className="text-wrapper-18">4</div>
            </div>

            <div className="property-7">
              <div className="text-wrapper-19">10</div>
            </div>

            <div className="property-8">
              <div className="text-wrapper-18">5</div>
            </div>

            <div className="property-9">
              <div className="text-wrapper-18">6</div>
            </div>

            <div className="overlap-group-13">
              <div className="property-ellipse">
                <div className="text-wrapper-20">No</div>
              </div>

              <div className="property-ellipse">
                <div className="text-wrapper-20">Yes</div>
              </div>
            </div>
          </div>

          <div className="group-30">
            <div className="btn-radio-10">
              <div className="ellipse-13" />
            </div>

            <div className="line-lineline-wrapper">
              <div className="line-lineline-3">
                <img
                  className="line-11"
                  alt="Line"
                  src="/img/line-65-4-2.svg"
                />
              </div>
            </div>
          </div>

          <div className="group-31">
            <div className="overlap-29">
              <img
                className="icon-close"
                alt="Icon close"
                src="/img/icon-close-2.png"
              />

              <div className="bg-icon" />
            </div>
          </div>

          <div className="frame-40">
            <div className="overlap-30">
              <div className="typography-17">
                <div className="heading-7">1.</div>
              </div>

              <div className="bg-icon-2" />
            </div>
          </div>

          <div className="overlap-31">
            <div className="btn-3">
              <div className="rectangle-41" />
            </div>

            <div className="typography-18">
              <div className="heading-8">BACK</div>
            </div>

            <IconArrowLeft1 className="icon-arrow-left-5" color="#005680" />
          </div>

          <div className="overlap-32">
            <div className="typography-19">
              <div className="heading-9">NEXT</div>
            </div>

            <ColorKeySizeMedium2 className="icon-arrow-left-4" color="white" />
          </div>

          <div className="typography-20">
            <div className="heading-9">OK</div>
          </div>

          <div className="group-32">
            <div className="btn-radio-11" />

            <div className="btn-radio-12">
              <div className="ellipse-13" />
            </div>

            <div className="btn-radio-13" />

            <div className="btn-radio-14" />

            <div className="btn-radio-15" />
          </div>

          <div className="overlap-33">
            <IconClose className="icon-close-1" color="#005680" />
            <div className="group-33">
              <div className="overlap-34">
                <div className="group-34">
                  <Btn4 className="btn-4" />
                </div>

                <div className="text-wrapper-21">Next</div>
              </div>

              <div className="overlap-35">
                <div className="group-34">
                  <Btn3 className="btn-4" />
                </div>

                <div className="text-wrapper-22">Skip</div>
              </div>
            </div>
          </div>

          <div className="group-35">
            <BgIcon1 className="bg-icon-1" />
            <BgIcon2 className="bg-icon-2-instance" />
            <BgIcon2 className="bg-icon-3" />
            <BgIcon2 className="bg-icon-4" />
            <BgIcon2 className="bg-icon-5" />
          </div>
        </div>
      </div>
    </div>
  );
};
