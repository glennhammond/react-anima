import React from "react";
import { Link } from "react-router-dom";
import { Btn } from "../../icons/Btn";
import { Check } from "../../icons/Check";
import { CloseSmall } from "../../icons/CloseSmall";
import { CloseSmall1 } from "../../icons/CloseSmall1";
import { CloseSmall2 } from "../../icons/CloseSmall2";
import { ColorKeySizeMedium2 } from "../../icons/ColorKeySizeMedium2";
import { IconArrowLeft1 } from "../../icons/IconArrowLeft1";
import { IconArrowLeft3 } from "../../icons/IconArrowLeft3";
import "./style.css";

export const Organisms = () => {
  return (
    <div className="organisms">
      <div className="div">
        <div className="overlap">
          <div className="page-title">
            <div className="title">
              <div className="text-wrapper">Organisms</div>
            </div>
          </div>

          <img
            className="devider-horizon"
            alt="Devider horizon"
            src="/img/devider-horizon-18.svg"
          />
        </div>

        <div className="page-header">
          <Link className="section-meta" to="/contents">
            <div className="text-wrapper-2">Contents</div>
          </Link>

          <Link className="section-meta" to="/documentation">
            <div className="text-wrapper-2">Documentation</div>
          </Link>

          <Link className="section-meta" to="/design">
            <div className="text-wrapper-2">Design</div>
          </Link>

          <Link className="section-meta" to="/development">
            <div className="text-wrapper-2">Development</div>
          </Link>

          <div className="logo" />
        </div>

        <div className="overlap-group">
          <div className="page-footer">
            <div className="credit">
              <div className="text-wrapper-3">© Glenn Hammond</div>
            </div>
          </div>

          <div className="group">
            <div className="heading-wrapper">
              <div className="heading">Tab 1</div>
            </div>

            <div className="div-wrapper">
              <div className="heading">Tab 2</div>
            </div>

            <div className="typography-wrapper">
              <div className="typography-2">
                <div className="heading">Tab 3</div>
              </div>
            </div>

            <div className="typography-3">
              <div className="heading">Tab 4</div>
            </div>

            <div className="overlap-2">
              <div className="typography-4">
                <div className="heading-2">Tab Three</div>
              </div>
            </div>
          </div>
        </div>

        <div className="rectangle" />

        <div className="overlap-3">
          <div className="divider">
            <img
              className="img"
              alt="Devider horizon"
              src="/img/devider-horizon.svg"
            />
          </div>

          <div className="row-assets">
            <div className="row-assets-2">
              <div className="title-doc">
                <div className="header">Groups of Molecules</div>

                <p className="p">
                  Images, media, and content files prepared for use.
                </p>
              </div>

              <p className="organisms-are">
                Organisms are relatively complex components composed of groups
                of molecules and/or atoms. <br />
                These could include headers, navigation bars, or product cards.
                Organisms serve as robust design patterns that balance
                flexibility and structure, offering more context and
                functionality within the layout.
              </p>

              <div className="overlap-group-wrapper">
                <div className="overlap-group-2">
                  <img
                    className="img"
                    alt="Devider horizon"
                    src="/img/devider-horizon.svg"
                  />

                  <div className="devider-horizon-wrapper">
                    <img
                      className="img"
                      alt="Devider horizon"
                      src="/img/devider-horizon.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="rectangle-2" />

        <div className="group-wrapper">
          <div className="overlap-wrapper">
            <div className="overlap-4">
              <div className="btn-radio" />

              <div className="placeholder-small" />

              <div className="bg" />

              <div className="group-2">
                <div className="btn-radio-2" />

                <div className="ellipse-wrapper">
                  <div className="ellipse" />
                </div>

                <div className="btn-radio-3" />

                <div className="btn-radio-4" />

                <div className="btn-radio-5" />
              </div>

              <div className="btn-2" />

              <div className="typography-5">
                <div className="heading-3">MORE</div>
              </div>

              <ColorKeySizeMedium2 className="icon-arrow-left" color="black" />
              <div className="body-wrapper">
                <p className="body">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Ut enim ad minim veniam, quis nostrud exercitation ullamco
                  laboris nisi ut aliquip ex ea commodo consequat.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="asset-progress">
          <div className="group-3">
            <div className="item">
              <div className="overlap-group-3">
                <div className="rectangle-3" />

                <Check className="check-instance" />
              </div>
            </div>

            <div className="title-2">Finished</div>

            <div className="description">This is a description.</div>

            <div className="overlap-5">
              <div className="item-2">
                <div className="head">
                  <div className="number-wrapper">
                    <div className="number">2</div>
                  </div>

                  <div className="title-3">In Progress</div>
                </div>

                <div className="description-wrapper">
                  <div className="description-2">This is a description.</div>
                </div>
              </div>

              <img className="line" alt="Line" src="/img/line-118.svg" />
            </div>

            <img className="line-2" alt="Line" src="/img/line-117.svg" />

            <div className="item-3">
              <div className="number-2">3</div>
            </div>

            <div className="title-4">Waiting</div>

            <div className="description-3">This is a description.</div>
          </div>
        </div>

        <div className="group-4">
          <div className="overlap-4">
            <div className="btn-radio" />

            <div className="placeholder-small" />

            <div className="group-5">
              <div className="btn-radio-2" />

              <div className="ellipse-wrapper">
                <div className="ellipse" />
              </div>

              <div className="btn-radio-3" />

              <div className="btn-radio-4" />

              <div className="btn-radio-5" />
            </div>

            <div className="btn-2" />

            <ColorKeySizeMedium2
              className="color-key-size-medium-2"
              color="black"
            />
            <IconArrowLeft1 className="icon-arrow-left-1" color="black" />
            <div className="typography-6">
              <p className="body">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris
                nisi ut aliquip ex ea commodo consequat.
              </p>
            </div>
          </div>
        </div>

        <div className="tootltip-sml-acme">
          <div className="tooltip">
            <img className="frame" alt="Frame" src="/img/frame-8.svg" />

            <div className="frame-2">
              <div className="frame-3">
                <div className="text-wrapper-4">Welcome!</div>

                <CloseSmall className="close-small" />
              </div>

              <div className="frame-4">
                <p className="text-wrapper-5">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua
                </p>

                <div className="frame-5">
                  <div className="frame-6">
                    <div className="ellipse-2" />

                    <div className="ellipse-3" />

                    <div className="ellipse-3" />

                    <div className="ellipse-3" />

                    <div className="ellipse-3" />
                  </div>

                  <div className="frame-7">
                    <div className="move-file">Next</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="tootltip-sml-key">
          <div className="style">
            <img className="frame-8" alt="Frame" src="/img/frame-7.svg" />

            <div className="frame-9">
              <div className="frame-10">
                <div className="frame-11">
                  <div className="ellipse-4" />

                  <div className="ellipse-5" />

                  <div className="ellipse-5" />

                  <div className="ellipse-5" />

                  <div className="ellipse-5" />
                </div>

                <CloseSmall1 className="close-small" />
              </div>

              <div className="frame-10">
                <div className="click-to-customize">Click to customise</div>
              </div>

              <div className="frame-5">
                <div className="frame-12">
                  <div className="move-file-2">Skip</div>
                </div>

                <div className="frame-13">
                  <div className="move-file-3">Next</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="tootltip-sml-base">
          <div className="style">
            <img className="frame-8" alt="Frame" src="/img/frame-7-1.svg" />

            <div className="frame-14">
              <div className="frame-10">
                <div className="frame-11">
                  <div className="ellipse-6" />

                  <div className="ellipse-7" />

                  <div className="ellipse-7" />

                  <div className="ellipse-7" />

                  <div className="ellipse-7" />
                </div>

                <CloseSmall2 className="close-small" />
              </div>

              <div className="frame-10">
                <div className="click-to-customize-2">Click to customise</div>
              </div>

              <div className="frame-5">
                <div className="frame-15">
                  <div className="move-file-4">Skip</div>
                </div>

                <div className="frame-16">
                  <div className="move-file-5">Next</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="card-img-text">
          <div className="overlap-6">
            <div className="card">
              <div className="rectangle-4" />
            </div>

            <div className="typography-7">
              <div className="heading-4">Title</div>
            </div>

            <div className="bg-2" />

            <div className="typography-8">
              <p className="body-2">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua.
              </p>
            </div>

            <div className="line-lineline">
              <img className="line-3" alt="Line" src="/img/line-65.svg" />
            </div>
          </div>
        </div>

        <div className="card-text">
          <div className="typography-9">
            <div className="heading-2">Title</div>
          </div>

          <div className="typography-10">
            <div className="heading-5">Subtitle</div>
          </div>

          <div className="typography-11">
            <p className="body">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </p>
          </div>

          <div className="line-wrapper">
            <img className="line-3" alt="Line" src="/img/line-65.svg" />
          </div>
        </div>

        <div className="overlap-7">
          <div className="group-6">
            <div className="overlap-8">
              <Btn className="btn-instance" />
              <div className="body-large-wrapper">
                <div className="body-large">Next</div>
              </div>

              <IconArrowLeft3 className="icon-arrow-left-3" />
            </div>
          </div>

          <div className="top-bar" />

          <div className="bg-3" />

          <div className="btn-radio-6" />

          <div className="btn-radio-7" />

          <div className="btn-radio-8" />

          <div className="btn-radio-9" />

          <div className="group-7" />

          <div className="typography-12">
            <p className="body-3">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </p>
          </div>

          <div className="rectangle-5" />

          <div className="typography-13">
            <div className="body-large">Welcome</div>
          </div>

          <div className="group-8">
            <div className="overlap-8">
              <Btn className="btn-instance" />
              <div className="body-large-wrapper">
                <div className="body-large">Next</div>
              </div>

              <IconArrowLeft3 className="icon-arrow-left-3" />
            </div>
          </div>

          <div className="group-9" />
        </div>
      </div>
    </div>
  );
};
