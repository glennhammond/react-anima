import React from "react";
import "./style.css";

export const Pages = () => {
  return (
    <div className="pages">
      <div className="div-34">
        <div className="overlap-group-34">
          <div className="rectangle-113" />

          <div className="rectangle-114" />

          <div className="divider-40">
            <img
              className="devider-horizon-40"
              alt="Devider horizon"
              src="/img/devider-horizon.svg"
            />
          </div>

          <p className="text-wrapper-93">
            Pages are fully realised examples of templates filled with actual
            content and imagery. They represent the final product that users
            interact with. Pages are essential for testing the effectiveness of
            a design system in real-world scenarios, helping teams evaluate
            usability, visual balance, and content flexibility.
          </p>
        </div>

        <div className="divider-41">
          <img
            className="devider-horizon-41"
            alt="Devider horizon"
            src="/img/devider-horizon-9.png"
          />
        </div>

        <div className="frame-59">
          <div className="header-63">Licence</div>

          <p className="header-64">License information is on the last page.</p>
        </div>

        <div className="page-footer-20">
          <div className="credit-20">
            <div className="text-wrapper-94">© Glenn Hammond</div>
          </div>
        </div>

        <div className="page-header-16">
          <div className="section-meta-20">
            <div className="text-wrapper-95">Contents</div>
          </div>

          <div className="logo-16" />
        </div>

        <div className="page-title-20">
          <div className="title-40">
            <div className="title-41">Pages</div>
          </div>
        </div>
      </div>
    </div>
  );
};
