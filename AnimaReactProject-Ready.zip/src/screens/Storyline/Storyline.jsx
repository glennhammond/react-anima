import React from "react";
import { Link } from "react-router-dom";
import "./style.css";

export const Storyline = () => {
  return (
    <div className="storyline">
      <div className="div-15">
        <div className="overlap-41">
          <div className="page-title-9">
            <div className="title-18">
              <div className="title-19">Storyline</div>
            </div>
          </div>

          <img
            className="devider-horizon-18"
            alt="Devider horizon"
            src="/img/devider-horizon-22.svg"
          />
        </div>

        <div className="page-header-9">
          <Link className="section-meta-9" to="/contents">
            <div className="text-wrapper-38">Contents</div>
          </Link>

          <Link className="section-meta-9" to="/documentation">
            <div className="text-wrapper-38">Documentation</div>
          </Link>

          <Link className="section-meta-9" to="/design">
            <div className="text-wrapper-38">Design</div>
          </Link>

          <Link className="section-meta-9" to="/development">
            <div className="text-wrapper-38">Development</div>
          </Link>

          <div className="logo-9" />
        </div>

        <div className="page-footer-9">
          <div className="credit-9">
            <div className="text-wrapper-39">© Glenn Hammond</div>
          </div>
        </div>

        <div className="rectangle-50" />

        <div className="divider-19">
          <img
            className="devider-horizon-19"
            alt="Devider horizon"
            src="/img/devider-horizon.svg"
          />
        </div>

        <div className="overlap-group-20">
          <div className="divider-20">
            <img
              className="devider-horizon-20"
              alt="Devider horizon"
              src="/img/devider-horizon-50.svg"
            />
          </div>

          <p className="element-title-lorem-ipsum-3">
            <span className="text-wrapper-40">1. Title</span>

            <span className="text-wrapper-41">
              {"  "}Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed
              do eiusmod tempor incididunt ut labore et dolore magna aliqua.
              {"  "}
            </span>
          </p>
        </div>

        <div className="row-development-4">
          <div className="title-doc-12">
            <div className="header-31">Considerations</div>

            <p className="header-32">
              Build process, coding, and technical implementation.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
