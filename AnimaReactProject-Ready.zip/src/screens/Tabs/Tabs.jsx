import React from "react";
import "./style.css";

export const Tabs = () => {
  return (
    <div className="tabs">
      <div className="div-28">
        <div className="divider-37">
          <img
            className="devider-horizon-37"
            alt="Devider horizon"
            src="/img/devider-horizon-9.png"
          />
        </div>

        <div className="frame-53">
          <div className="header-54">Licence</div>

          <p className="header-55">License information is on the last page.</p>
        </div>

        <div className="page-footer-17">
          <div className="credit-17">
            <div className="text-wrapper-83">© Glenn Hammond</div>
          </div>
        </div>

        <div className="page-title-17">
          <div className="title-34">
            <div className="title-35">Tabs</div>
          </div>
        </div>

        <div className="rectangle-70" />

        <div className="section-meta-17">
          <div className="text-wrapper-84">Contents</div>
        </div>

        <div className="nautilus">
          <div className="overlap-group-31">
            <img className="vector-41" alt="Vector" src="/img/vector-21.svg" />

            <img className="vector-42" alt="Vector" src="/img/vector-22.svg" />

            <img className="vector-43" alt="Vector" src="/img/vector-23.svg" />

            <img className="vector-44" alt="Vector" src="/img/vector-24.svg" />

            <img className="vector-45" alt="Vector" src="/img/vector-25.svg" />

            <img className="vector-46" alt="Vector" src="/img/vector-26.svg" />

            <img className="vector-47" alt="Vector" src="/img/vector-27.svg" />

            <img className="vector-48" alt="Vector" src="/img/vector-28.svg" />

            <img className="vector-49" alt="Vector" src="/img/vector-29.svg" />

            <img className="vector-50" alt="Vector" src="/img/vector-30.svg" />

            <img className="vector-51" alt="Vector" src="/img/vector-31.svg" />

            <img className="vector-52" alt="Vector" src="/img/vector-32.svg" />

            <img className="vector-53" alt="Vector" src="/img/vector-33.svg" />

            <img className="vector-54" alt="Vector" src="/img/vector-34.svg" />

            <img className="vector-55" alt="Vector" src="/img/vector-35.svg" />

            <img className="vector-57" alt="Vector" src="/img/vector-36.svg" />

            <img className="vector-58" alt="Vector" src="/img/image.svg" />

            <img className="vector-59" alt="Vector" src="/img/vector-38.svg" />

            <img
              className="vector-60"
              alt="Vector"
              src="/img/vector-39-2.svg"
            />

            <img className="vector-61" alt="Vector" src="/img/vector-40.svg" />

            <img
              className="vector-62"
              alt="Vector"
              src="/img/vector-41-2.svg"
            />

            <img
              className="vector-63"
              alt="Vector"
              src="/img/vector-42-2.svg"
            />

            <img className="vector-64" alt="Vector" src="/img/vector-43.svg" />

            <img
              className="vector-65"
              alt="Vector"
              src="/img/vector-44-2.svg"
            />

            <img
              className="vector-66"
              alt="Vector"
              src="/img/vector-45-2.svg"
            />

            <img className="vector-67" alt="Vector" src="/img/vector-46.svg" />

            <img
              className="vector-68"
              alt="Vector"
              src="/img/vector-47-2.svg"
            />

            <img className="vector-69" alt="Vector" src="/img/vector-48.svg" />

            <img className="vector-70" alt="Vector" src="/img/vector-49.svg" />

            <img
              className="vector-71"
              alt="Vector"
              src="/img/vector-50-2.svg"
            />

            <img className="vector-72" alt="Vector" src="/img/vector-51.svg" />

            <img className="vector-73" alt="Vector" src="/img/vector-52.svg" />

            <img className="vector-74" alt="Vector" src="/img/vector-53.svg" />

            <img className="vector-75" alt="Vector" src="/img/vector-54.svg" />

            <img className="vector-76" alt="Vector" src="/img/vector-55.svg" />

            <img className="vector-77" alt="Vector" src="/img/vector-56.svg" />

            <img className="vector-78" alt="Vector" src="/img/vector-57.svg" />

            <img className="vector-79" alt="Vector" src="/img/vector-58.svg" />

            <img className="vector-80" alt="Vector" src="/img/vector-59.svg" />

            <img className="vector-81" alt="Vector" src="/img/vector-60.svg" />

            <img className="vector-82" alt="Vector" src="/img/vector-61.svg" />

            <img className="vector-83" alt="Vector" src="/img/vector-62.svg" />

            <img className="vector-84" alt="Vector" src="/img/vector-63.svg" />
          </div>
        </div>

        <div className="component">
          <div className="overlap-62">
            <div className="btn-sml-examples-2">
              <div className="typography-34">
                <div className="heading-15">Tab One</div>
              </div>
            </div>

            <div className="btn-sml-examples-3">
              <div className="typography-34">
                <div className="heading-16">Tab Two</div>
              </div>
            </div>

            <div className="btn-sml-examples-4">
              <div className="typography-34">
                <div className="heading-17">Tab Three</div>
              </div>
            </div>

            <div className="btn-sml-examples-5">
              <div className="typography-34">
                <div className="heading-15">Tab Four</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
