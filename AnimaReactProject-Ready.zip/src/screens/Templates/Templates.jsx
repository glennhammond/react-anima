import React from "react";
import "./style.css";

export const Templates = () => {
  return (
    <div className="templates">
      <div className="div-37">
        <div className="overlap-70">
          <div className="rectangle-120" />

          <div className="divider-44">
            <img
              className="devider-horizon-44"
              alt="Devider horizon"
              src="/img/devider-horizon-5.svg"
            />
          </div>

          <div className="rectangle-121" />

          <img className="group-78" alt="Group" src="/img/group-676.png" />

          <div className="rectangle-122" />

          <div className="group-79">
            <div className="typography-39">
              <div className="text-wrapper-126">Accordion</div>
            </div>

            <div className="line-27">
              <div className="line-lineline-6">
                <img className="line-28" alt="Line" src="/img/line-65-6.svg" />
              </div>
            </div>

            <div className="group-80">
              <div className="overlap-group-38">
                <img
                  className="img-5"
                  alt="Icon arrow left"
                  src="/img/icon-arrow-left-11.svg"
                />

                <img className="img-5" alt="Bg icon" src="/img/bg-icon-6.svg" />
              </div>
            </div>
          </div>

          <div className="group-81">
            <div className="typography-39">
              <div className="text-wrapper-126">Accordion 2</div>
            </div>

            <div className="line-27">
              <div className="line-lineline-6">
                <img className="line-28" alt="Line" src="/img/line-65-7.svg" />
              </div>
            </div>

            <div className="bg-icon-wrapper">
              <img
                className="bg-icon-9"
                alt="Bg icon"
                src="/img/bg-icon-7.svg"
              />
            </div>
          </div>

          <div className="group-82">
            <div className="typography-39">
              <div className="text-wrapper-126">Heading 5</div>
            </div>

            <div className="line-27">
              <div className="line-lineline-6">
                <img className="line-28" alt="Line" src="/img/line-65-8.svg" />
              </div>
            </div>

            <div className="group-83">
              <img
                className="bg-icon-9"
                alt="Bg icon"
                src="/img/bg-icon-8.svg"
              />
            </div>
          </div>

          <div className="typography-40">
            <p className="body-9">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim ad minim veniam, quis nostrud exercitation ullamco laboris
              nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
              reprehenderit in voluptate velit esse cillum dolore eu fugiat
              nulla pariatur.
            </p>
          </div>

          <div className="cards">
            <div className="card-4">
              <div className="group-84">
                <div className="overlap-71">
                  <div className="overlap-group-wrapper-3">
                    <div className="overlap-group-39">
                      <img
                        className="rectangle-123"
                        alt="Rectangle"
                        src="/img/rectangle-132-2.svg"
                      />
                    </div>
                  </div>

                  <div className="group-85" />

                  <img
                    className="icon-head"
                    alt="Icon head"
                    src="/img/icon-head-2.svg"
                  />
                </div>
              </div>
            </div>

            <div className="card-5">
              <div className="overlap-group-wrapper-3">
                <div className="overlap-group-39">
                  <img
                    className="rectangle-123"
                    alt="Rectangle"
                    src="/img/rectangle-132-2.svg"
                  />
                </div>
              </div>

              <div className="group-86" />

              <img
                className="icon-head-2"
                alt="Icon head"
                src="/img/icon-head.svg"
              />
            </div>

            <div className="card-back">
              <div className="group-84">
                <div className="overlap-71">
                  <div className="overlap-group-wrapper-3">
                    <div className="overlap-group-39">
                      <img
                        className="rectangle-123"
                        alt="Rectangle"
                        src="/img/rectangle-132-2.svg"
                      />
                    </div>
                  </div>

                  <div className="line-lineline-7">
                    <img
                      className="line-29"
                      alt="Line"
                      src="/img/line-65-9.svg"
                    />
                  </div>

                  <div className="typography-41">
                    <p className="body-9">
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Sed do eiusmod tempor incididunt ut labore et dolore magna
                      aliqua.
                    </p>
                  </div>

                  <div className="typography-42">
                    <div className="text-wrapper-126">...back</div>
                  </div>

                  <div className="typography-43">
                    <div className="heading-21">Label</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="card-6">
              <div className="overlap-71">
                <div className="overlap-group-wrapper-3">
                  <div className="overlap-71">
                    <div className="overlap-group-wrapper-3">
                      <div className="overlap-group-39">
                        <img
                          className="rectangle-123"
                          alt="Rectangle"
                          src="/img/rectangle-132-2.svg"
                        />
                      </div>
                    </div>

                    <img
                      className="icon-more-6"
                      alt="Icon more"
                      src="/img/color-key-size-medium-orientation-horizontal.svg"
                    />

                    <div className="group-85" />

                    <img
                      className="icon-head"
                      alt="Icon head"
                      src="/img/icon-head-1.svg"
                    />
                  </div>
                </div>

                <div className="typography-44">
                  <div className="heading-21">Label</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-70">
            <div className="bg-4" />

            <div className="typography-45">
              <p className="body-9">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua.
              </p>
            </div>

            <img
              className="icon-more-7"
              alt="Icon more"
              src="/img/color-key-size-medium-orientation-horizontal.svg"
            />
          </div>

          <div className="frame-71">
            <div className="bg-4" />

            <div className="typography-45">
              <p className="body-9">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua.
              </p>
            </div>

            <img
              className="icon-more-7"
              alt="Icon more"
              src="/img/color-key-size-medium-orientation-horizontal.svg"
            />
          </div>

          <div className="frame-72">
            <div className="bg-4" />

            <div className="typography-45">
              <p className="body-9">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua.
              </p>
            </div>

            <img
              className="icon-more-7"
              alt="Icon more"
              src="/img/color-key-size-medium-orientation-horizontal.svg"
            />
          </div>

          <div className="bg-5" />

          <p className="text-wrapper-127">
            Templates define the underlying content structure and layout of a
            page by combining organisms into a cohesive format. While they show
            placement and hierarchy, templates are devoid of actual content.
            They allow teams to visualise how components will work together and
            ensure consistency in design before real content is applied.
          </p>

          <div className="frame-73">
            <div className="btn-radio-17">
              <div className="ellipse-19" />
            </div>

            <div className="overlap-72">
              <div className="btn-radio-18" />

              <div className="typography-46">
                <div className="heading-22">Answer 2</div>
              </div>

              <div className="rectangle-124" />
            </div>

            <div className="btn-radio-19" />

            <div className="btn-radio-20" />

            <div className="typography-47">
              <div className="heading-22">Answer 1</div>
            </div>

            <div className="typography-48">
              <div className="heading-22">Answer 3</div>
            </div>

            <div className="typography-49">
              <div className="heading-22">Answer 4</div>
            </div>

            <div className="line-30">
              <div className="line-lineline-6">
                <img
                  className="line-31"
                  alt="Line"
                  src="/img/line-65-4-2.svg"
                />
              </div>
            </div>

            <div className="line-32">
              <div className="line-lineline-6">
                <img
                  className="line-31"
                  alt="Line"
                  src="/img/line-65-4-2.svg"
                />
              </div>
            </div>

            <div className="line-33">
              <div className="line-lineline-6">
                <img
                  className="line-31"
                  alt="Line"
                  src="/img/line-65-4-2.svg"
                />
              </div>
            </div>

            <div className="line-34">
              <div className="line-lineline-6">
                <img
                  className="line-31"
                  alt="Line"
                  src="/img/line-65-4-2.svg"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="frame-74">
          <div className="header-69">Licence</div>

          <p className="header-70">License information is on the last page.</p>
        </div>

        <div className="page-footer-23">
          <div className="credit-23">
            <div className="text-wrapper-128">© Glenn Hammond</div>
          </div>
        </div>

        <div className="page-title-23">
          <div className="title-46">
            <div className="title-47">Templates</div>
          </div>
        </div>

        <div className="section-meta-23">
          <div className="text-wrapper-129">Contents</div>
        </div>
      </div>
    </div>
  );
};
