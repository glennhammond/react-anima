import React from "react";
import "./style.css";

export const Typo = () => {
  return (
    <div className="typo">
      <div className="div-35">
        <div className="overlap-group-35">
          <div className="page-title-21">
            <div className="title-42">
              <div className="title-43">Typography</div>
            </div>
          </div>

          <div className="text-wrapper-96">Headings</div>

          <div className="font-size-line">Style</div>

          <div className="font-size-line-2">Font size/line height</div>

          <div className="frame-60">
            <div className="group-68">
              <div className="text-wrapper-97">H1</div>

              <div className="text-wrapper-98">96/auto</div>

              <div className="text-wrapper-99">80/auto</div>
            </div>
          </div>

          <div className="text-7">Century Gothic</div>

          <div className="frame-61">
            <div className="group-69">
              <div className="text-wrapper-100">H2</div>

              <div className="text-wrapper-101">56/auto</div>

              <div className="text-wrapper-102">48/auto</div>
            </div>
          </div>

          <div className="frame-62">
            <div className="group-70">
              <div className="text-wrapper-103">H3</div>

              <div className="text-wrapper-104">48/auto</div>

              <div className="text-wrapper-105">36/auto</div>
            </div>
          </div>

          <div className="frame-63">
            <div className="group-71">
              <div className="text-wrapper-106">H4</div>

              <div className="text-wrapper-107">40/auto</div>

              <div className="text-wrapper-108">28/auto</div>
            </div>
          </div>

          <div className="frame-64">
            <div className="group-72">
              <div className="text-wrapper-109">H5</div>

              <div className="text-wrapper-110">32/auto</div>

              <div className="text-wrapper-111">24/auto</div>
            </div>
          </div>

          <div className="text-wrapper-112">Body</div>

          <div className="type-scale">
            <div className="frame-65">
              <div className="group-73">
                <div className="text-wrapper-113">Body large</div>

                <div className="text-wrapper-114">32/auto</div>

                <div className="text-wrapper-115">24/auto</div>
              </div>
            </div>

            <div className="frame-66">
              <div className="group-74">
                <div className="text-wrapper-116">H2</div>

                <div className="text-wrapper-117">28/auto</div>

                <div className="text-wrapper-118">22/auto</div>
              </div>
            </div>
          </div>

          <div className="text-8">Open Sans</div>

          <div className="text-wrapper-119">Font weight</div>

          <div className="frame-67">
            <div className="text-wrapper-120">Regular 400</div>

            <div className="text-wrapper-121">Medium 500</div>

            <img className="line-23" alt="Line" src="/img/line-1-2.svg" />
          </div>
        </div>

        <div className="divider-42">
          <img
            className="devider-horizon-42"
            alt="Devider horizon"
            src="/img/devider-horizon-9.png"
          />
        </div>

        <div className="frame-68">
          <div className="header-65">Licence</div>

          <p className="header-66">License information is on the last page.</p>
        </div>

        <div className="page-footer-21">
          <div className="credit-21">
            <div className="text-wrapper-122">© Glenn Hammond</div>
          </div>
        </div>

        <div className="rectangle-115" />

        <div className="section-meta-21">
          <div className="text-wrapper-123">Contents</div>
        </div>
      </div>
    </div>
  );
};
