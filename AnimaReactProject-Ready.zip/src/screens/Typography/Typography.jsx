import React from "react";
import "./style.css";

export const Typography = () => {
  return (
    <div className="typography">
      <img className="img-6" alt="Typography" src="/img/typography.png" />

      <div className="table-typography">
        <div className="text-wrapper-130">Headings</div>

        <div className="text-wrapper-131">Body</div>

        <div className="text-wrapper-132">Font weight</div>

        <div className="text-9">Century Gothic</div>

        <div className="text-10">Open Sans</div>

        <div className="font-size-line-3">Style</div>

        <div className="font-size-line-4">Font size/line height</div>

        <div className="font-size-line-5">Storyline size/line height</div>

        <div className="frame-75">
          <div className="group-87">
            <div className="text-wrapper-133">H1</div>

            <div className="text-wrapper-134">96/auto</div>

            <div className="text-wrapper-135">80/auto</div>
          </div>
        </div>

        <div className="frame-76">
          <div className="group-88">
            <div className="text-wrapper-136">H2</div>

            <div className="text-wrapper-137">56/auto</div>

            <div className="text-wrapper-138">48/auto</div>
          </div>
        </div>

        <div className="frame-77">
          <div className="group-89">
            <div className="text-wrapper-139">H3</div>

            <div className="text-wrapper-140">48/auto</div>

            <div className="text-wrapper-141">36/auto</div>
          </div>
        </div>

        <div className="frame-78">
          <div className="group-90">
            <div className="text-wrapper-142">H4</div>

            <div className="text-wrapper-143">40/auto</div>

            <div className="text-wrapper-144">28/auto</div>
          </div>
        </div>

        <div className="frame-79">
          <div className="group-91">
            <div className="text-wrapper-145">H5</div>

            <div className="text-wrapper-146">32/auto</div>

            <div className="text-wrapper-147">24/auto</div>
          </div>
        </div>

        <div className="type-scale-2">
          <div className="frame-80">
            <div className="group-92">
              <div className="text-wrapper-148">Body large</div>

              <div className="text-wrapper-149">32/auto</div>

              <div className="text-wrapper-150">24/auto</div>
            </div>
          </div>

          <div className="frame-81">
            <div className="group-93">
              <div className="text-wrapper-151">H2</div>

              <div className="text-wrapper-152">28/auto</div>

              <div className="text-wrapper-153">22/auto</div>
            </div>
          </div>
        </div>

        <div className="frame-82">
          <div className="text-wrapper-154">Regular 400</div>

          <div className="text-wrapper-155">Medium 500</div>

          <img className="line-35" alt="Line" src="/img/line-1-2.svg" />
        </div>
      </div>
    </div>
  );
};
